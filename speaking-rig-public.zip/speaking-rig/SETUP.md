# Speaking Rig

A conversation partner for spoken Mandarin that runs entirely on your Mac.
No account, no internet, no subscription, nothing leaves the machine.

You hold a button and speak. It shows what it heard, and how sure it is. The
other person answers you out loud. Then it is your turn again.

---

# Part 1. Setting it up, once

You will use Terminal. If you have never opened it, that is fine. Everything
below is copy, paste, press return.

## Step 1. Put the folder in your home folder

So that its path is `~/speaking-rig`.

## Step 2. Open Terminal

Press `Command` and `Space` together, type `Terminal`, press return.

## Step 3. Run the setup

```
cd ~/speaking-rig && chmod +x setup.sh start.sh && ./setup.sh
```

Six steps, about ten minutes, nearly all downloading. It may stop and ask you
to install Homebrew, or Ollama from ollama.com, or the Chinese voice. Do that,
then run step 3 again.

## Step 4. Start it

Double-click **start.sh**, or run `~/speaking-rig/start.sh`.

**The start screen now shows a system list.** Six lines, each green or red,
telling you exactly which parts are working: the word splitter, the pinyin
dictionary, Ollama, whether a model is installed, the speech recogniser, and
the Chinese voice. If anything is red it says what to do about it, and the
Start button stays disabled until the essentials are green.

That list exists because an earlier version failed silently and there was no
way to tell which piece had gone.

---

# Part 2. Using it

**Write the situation.** One line about who you are talking to and what is
going on. Not a job title, a situation. Three examples appear underneath, and
shuffle gives three more. Whatever you type is remembered under **Again**.

**Pick your level and model.** HSK 1 to 3, or free chat.

**Press Start talking**, accept the microphone prompt, and the other person
speaks first.

**Then talk.** Hold the bar at the bottom, or hold the **spacebar**. Take as
long as you need. Nothing cuts you off.

## The bar is a level meter

While you hold it, the fill tracks your microphone input. If you speak and it
barely moves, the problem is the audio path, not your Mandarin. Nothing is sent
if no sound registered, and it tells you so.

Check this first whenever recognition goes strange. Nearly every bizarre
transcription comes from near-silence, because the recogniser fills the gap
with whatever its training data suggests.

## What happens to your turn

The recogniser reports how confident it is, and that decides everything. This
is the recogniser's own number, not a model's opinion.

**Confident.** Your line appears and the conversation continues. No fuss.

**Fairly confident.** Same, plus a quiet note saying it heard this but is not
certain. The conversation still continues.

**Not confident.** Your line appears greyed, and the other person says they did
not catch it and asks their question again in simpler words. Nothing you did
not say enters the conversation.

The number itself is shown under the speak bar, so you can watch it and learn
what your own clear speech scores.

## Fixing a turn

**or ...** chips offer other readings of the same sounds. They come from a
dictionary, not from a model, so they are always real sentences you could have
said. Tap one and the conversation rewinds and continues from there.

**type it** opens a box. Type what you meant in pinyin, with or without tone
marks, or in characters. An apostrophe marks a syllable boundary where it
matters: `xi'an` gives 西安, `xian` gives 咸. This is a dictionary lookup, so it is instant and
works even when the model is having a bad day.

**my voice** plays your own recording. This is the only thing on screen that is
actually what you said.

**Replay** and **Slower** on the other person's lines.

## Ending

**End session** gives a plain count, a list of the turns it was unsure about
with their confidence numbers, and **Copy transcript**. Tick **include
characters** if you want the Chinese too, which is what you would want if you
were showing it to a teacher. Recordings are deleted.

---

# Part 3. Before you change anything

There is a test suite. Run it before and after any change:

```
cd ~/speaking-rig && source .venv/bin/activate && python tests/regression.py
```

107 checks, a few seconds, no microphone or model needed. Every check exists
because something broke once, and the comment on each says what. If the pass
count drops, the change broke something that used to work.

`DECISIONS.md` explains why the app is built the way it is, including several
approaches that were tried and abandoned. Worth reading before proposing a
redesign, and worth handing to anyone helping with this.

# Part 4. Changing it

**Two settings at the top of `server.py` control the recogniser prompt.**
`PRIMER_WORDS` is how many words are suggested to the recogniser each turn,
default 12. A long prompt is actively harmful: at around 28 words it started
producing English repetition loops in testing. Set `PRIMER_WORDS=0` to switch
priming off entirely and compare.

**The Listening with dropdown on the start screen** is the most important
setting in the app. It chooses which Whisper model transcribes you.

- **large-v2** is the default and the steadiest on Chinese.
- **large-v3** is newer and reported to loop more often.
- **medium** is faster and less accurate.
- **large-v3-turbo** is the fastest and loops the most. It has four decoder
  layers instead of thirty-two, and on learner Mandarin it produces repeated
  nonsense on perfectly good recordings.

If a turn comes back as the same syllable repeated, change this before
changing anything else. Each model downloads the first time you select it.
When a recogniser loops twice on one recording, the server automatically tries
the fallback model before giving up.

**hotwords.json** nudges the recogniser towards particular words. Add anything
it keeps mishearing, especially names and places. Keep it under about sixty
entries. A core of short answers is always included on top of this.

**levels.json** controls the four levels. `max_chars` caps reply length and is
the most useful setting in the file.

**seeds.json** is the list of example situations.

The persona rules live in `server.py` under `persona_prompt`, in plain English.

Two numbers control the confidence policy, at the top of `server.py`:
`ACCEPT_AT` (above this, accepted silently) and `CHECK_AT` (below this, not
accepted at all). Watch the confidence numbers for a session or two, then move
them if the thresholds feel wrong for your voice.

---

# Part 5. When something is wrong

**Start with the start screen.** Two buttons under the system list:

**Check again** re-runs the six component checks.

**Run a test conversation** is the important one. It runs the whole pipeline
with a fixed sentence and no microphone: dictionary, typing, pinyin, the model,
an opening line, a reply, a clarification, the English gloss and the voice.
Each stage passes or fails on its own line with a timing, so a failure points
at one component rather than at the whole app. There is a Copy this result
button, and that text is the single most useful thing to send if you need help.

If the test passes but speaking still does nothing, the problem is the
microphone or the recogniser, and the transcript will now say which.

**A change did not take effect.** The build number is on the start screen and
in the header. The server reloads itself when `server.py` changes, but if the
number is not what you installed, press Control and C in the Terminal window
and run `start.sh` again.

**When a turn is not used**, the block on screen has a **type it instead**
link. Use that rather than going back to edit an earlier turn: editing an
earlier turn deliberately discards everything after it, because the
conversation from that point was answering something you did not say.

**A turn was not used.** This now appears as a block in the conversation
itself rather than a small grey line, and it says why: the reason, what the
recogniser actually transcribed, the confidence, and your microphone level for
that turn. A microphone level below about 0.01 means nothing reached the
recogniser and everything downstream is guesswork.

**Everything is slow.** The line under the speak bar shows seconds per stage.
Switch to a smaller model on the start screen if replying is the slow part.

**First turn of the day is slow.** Normal. The model loads and then stays warm
for thirty minutes.

**Short replies keep failing.** One or two syllables is genuinely hard for any
recogniser, because there is nothing around them to work with. A carrier phrase
helps a lot and is better practice anyway: 对，我也是 rather than a bare 对.

---

# What this deliberately does not do

**No tone scoring.** Recognisers reconstruct tone from context rather than
hearing it. Real tone feedback needs pitch tracking against a reference, which
is a separate project.

**No language model between you and the conversation.** An earlier version put
one there to "work out what you meant". It had no access to the audio, no
calibrated confidence, and every incentive to write a better sentence than the
one you said. It invented whole turns. What you said is now decided by the
recogniser and the dictionary only.

**No scores, streaks, grades or congratulation.** The other person is not a
teacher and never breaks character to become one.
