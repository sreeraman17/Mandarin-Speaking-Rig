"""
Speaking Rig, local server.

Architecture note, because the previous version got this wrong.

An earlier design put a language model between the recogniser and the
conversation, asking it to "work out what the learner meant". That model has no
access to the audio, no calibrated confidence, and every incentive to write a
better sentence than the one you said. It invented turns, and each guard added
to catch the inventions broke something else.

This version does not do that. The recogniser's output is what you said. The
recogniser's own confidence decides what happens next, following the standard
three-tier policy from the spoken dialogue literature (Bohus 2007, Skantze 2007):

    high confidence   -> accept silently
    medium confidence -> accept, and show what was heard (implicit confirmation)
    low confidence    -> do not accept; the other person asks about it

Alternative readings are produced by re-segmenting the same syllables through a
dictionary, so they are always things you could actually have said. No model is
involved in deciding what you said, at any point.

One model call per turn: the other person's reply. Plus a small translation
call that never blocks anything.
"""

import difflib
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

import httpx
from fastapi import FastAPI, Form, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pypinyin import Style, lazy_pinyin, load_phrases_dict

BUILD = "2026-08-16.70"

ROOT = Path(__file__).parent
WORK = Path(tempfile.gettempdir()) / "speaking_rig"
WORK.mkdir(exist_ok=True)

OLLAMA = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
# Recogniser choice matters more than anything else in this file.
#
# large-v3-turbo has four decoder layers instead of thirty-two. It is fast, and
# it is the most repetition-prone variant on non-English audio. Shipping it as
# the default for learner Mandarin was a mistake: it produced "yine yine yine"
# on perfectly good recordings. large-v2 is widely reported as the most stable
# for Chinese, so it is the default now, with the others one click away.
ASR_CHOICES = [
    {"id": "mlx-community/whisper-large-v2-mlx",
     "label": "large-v2  (steadiest on Chinese)", "size": "~3GB"},
    {"id": "mlx-community/whisper-large-v3-mlx",
     "label": "large-v3  (newer, more prone to looping)", "size": "~3GB"},
    {"id": "mlx-community/whisper-medium-mlx",
     "label": "medium  (faster, less accurate)", "size": "~1.5GB"},
    {"id": "mlx-community/whisper-large-v3-turbo",
     "label": "large-v3-turbo  (fastest, loops most)", "size": "~1.6GB"},
]
WHISPER_REPO = os.environ.get("WHISPER_REPO", ASR_CHOICES[0]["id"])
ASR_FALLBACK = os.environ.get("ASR_FALLBACK", "mlx-community/whisper-medium-mlx")
TTS_VOICE = os.environ.get("TTS_VOICE", "Tingting")

# A recogniser that is not on disk yet is a multi-minute download. Doing that
# in the middle of a conversation is a stall with nothing on screen explaining
# it, which is exactly what happened: one badly heard turn triggered a 1.5GB
# fetch of the fallback and the session sat there for seven minutes. Nothing
# downloads during a session now. Everything is fetched by setup.sh.
_ASR_ON_DISK = set()


def asr_cached(repo: str) -> bool:
    """True when this recogniser is already downloaded. Never fetches.

    A yes is remembered, since a model does not leave the disk mid-session.
    A no is rechecked every time, so a download finished in another window is
    picked up without restarting the server."""
    if not repo:
        return False
    if repo in _ASR_ON_DISK:
        return True
    ok = False
    try:
        if os.path.isdir(repo):
            ok = True
        else:
            from huggingface_hub import snapshot_download
            d = Path(snapshot_download(repo, local_files_only=True))
            names = {f.name for f in d.iterdir()}
            # A half-finished download leaves the folder there with pieces
            # missing, so check for the parts that actually get loaded rather
            # than for the folder.
            ok = "config.json" in names and any(
                n.endswith((".npz", ".safetensors", ".bin")) for n in names)
    except Exception:
        ok = False
    if ok:
        _ASR_ON_DISK.add(repo)
    return ok

# Confidence policy. Tune these two numbers and nothing else changes.
ACCEPT_AT = float(os.environ.get("ACCEPT_AT", "0.55"))   # above this, silent
CHECK_AT = float(os.environ.get("CHECK_AT", "0.30"))     # below this, not caught

# A long prompt makes Whisper echo it or wander out of Chinese entirely. This
# was measured: at roughly 28 words it started producing English repetition
# loops. Twelve is safe. Set PRIMER_WORDS=0 to switch priming off and compare.
# Off by default: you asked for no friction layer, and the dialogue research
# agrees that implicit confirmation suits a task with nothing to complete.
# Set CONFIRM_UNCERTAIN=1 to make a not-certain turn wait for you instead.
CONFIRM_UNCERTAIN = os.environ.get("CONFIRM_UNCERTAIN", "0") == "1"

PRIMER_WORDS = int(os.environ.get("PRIMER_WORDS", "12"))
PRIMER_CHARS = int(os.environ.get("PRIMER_CHARS", "150"))

CJK = re.compile(r"[\u4e00-\u9fff]")
app = FastAPI(title="Speaking Rig")

try:
    import jieba
    jieba.setLogLevel(60)
    HAVE_JIEBA = True
except Exception:
    HAVE_JIEBA = False


def seg(s: str) -> list:
    if HAVE_JIEBA:
        return list(jieba.cut(s, HMM=False))
    return list(s)


# ------------------------------------------------------------------ pinyin
# pypinyin gets neutral tones wrong on common words. Corrections carried over
# from the hub work, where these were caught by hand.
load_phrases_dict({
    "朋友": [["péng"], ["you"]], "太太": [["tài"], ["tai"]],
    "厉害": [["lì"], ["hai"]], "和尚": [["hé"], ["shang"]],
    "老人家": [["lǎo"], ["rén"], ["jia"]], "东西": [["dōng"], ["xi"]],
    "喜欢": [["xǐ"], ["huan"]], "谢谢": [["xiè"], ["xie"]],
    "先生": [["xiān"], ["sheng"]], "意思": [["yì"], ["si"]],
    "衣服": [["yī"], ["fu"]], "时候": [["shí"], ["hou"]],
    "知道": [["zhī"], ["dao"]], "我们": [["wǒ"], ["men"]],
    "你们": [["nǐ"], ["men"]], "他们": [["tā"], ["men"]],
    "什么": [["shén"], ["me"]], "怎么": [["zěn"], ["me"]],
    "这个": [["zhè"], ["ge"]], "那个": [["nà"], ["ge"]],
    "多少": [["duō"], ["shao"]], "便宜": [["pián"], ["yi"]],
    "漂亮": [["piào"], ["liang"]], "认识": [["rèn"], ["shi"]],
    "休息": [["xiū"], ["xi"]], "麻烦": [["má"], ["fan"]],
    "客气": [["kè"], ["qi"]], "关系": [["guān"], ["xi"]],
    "明白": [["míng"], ["bai"]], "告诉": [["gào"], ["su"]],
    "眼睛": [["yǎn"], ["jing"]], "耳朵": [["ěr"], ["duo"]],
    "孩子": [["hái"], ["zi"]], "妻子": [["qī"], ["zi"]],
})

_SPLIT = {"那要", "你家", "我家", "他家", "她家"}
_LEAD = "很不没也都太真最更又还就别挺"
_KEEP = {"不错", "不是", "不用", "不但", "不过", "不管", "不然", "不同",
         "不行", "不少", "不多", "不要", "没有", "也许", "还是", "还有",
         "就是", "别人", "太太", "真的", "最好", "更好"}
_NUM = re.compile(r"^([一二三四五六七八九十百千两几零]+)([个位件本杯次年月天块岁点分口只张多钱]+)$")
_PUNCT = {"，": ",", "。": ".", "？": "?", "！": "!", "：": ":", "；": ";",
          "、": ",", "…": "...", "“": '"', "”": '"', "‘": "'", "’": "'"}
_IS4 = re.compile(r"[àèìòùǜ]")
_HASTONE = re.compile(r"[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]")
_PROPER = {"chéngdū", "běijīng", "shànghǎi", "yìndù", "mèngmǎi", "zhōngguó",
           "xīnjiāpō", "guǎngzhōu", "shēnzhèn", "xiānggǎng", "táiwān",
           "xīndélǐ", "měiguó", "yīngguó", "rìběn", "hánguó", "chóngqìng",
           "hángzhōu", "nánjīng", "wǔhàn", "tiānjīn", "xīhú"}


def _syl(tok):
    return [s for s in lazy_pinyin(tok, style=Style.TONE, errors=lambda x: list(x))
            if s.strip()]


def _erhua(syl, tok):
    if len(syl) > 1 and tok.endswith("儿") and syl[-1] in ("ér", "er", "r"):
        return syl[:-2] + [syl[-2] + "r"]
    return syl


def _first_tone(word: str) -> str:
    """The tone of the first syllable only. 高兴 is first tone, even though
    xìng later in the word is fourth."""
    m = _HASTONE.search(word)
    return m.group(0) if m else ""


def _sandhi(syl):
    """一 and 不 shift tone before a fourth tone, written in as the books do."""
    for i, s in enumerate(syl[:-1]):
        nxt4 = bool(_IS4.match(_first_tone(syl[i + 1])))
        if s in ("bù", "bú"):
            syl[i] = "bú" if nxt4 else "bù"
        elif s in ("yī", "yí", "yì") and _HASTONE.search(syl[i + 1]):
            syl[i] = "yí" if nxt4 else "yì"
    return syl


def _as_words(tok):
    syl = _sandhi(_erhua(_syl(tok), tok))
    if len(syl) < 2 or tok in _KEEP:
        return ["".join(syl)]
    if tok in _SPLIT:
        return syl
    m = _NUM.match(tok)
    if m:
        n = len(m.group(1))
        return ["".join(syl[:n])] + syl[n:]
    if tok[0] in _LEAD:
        return [syl[0], "".join(syl[1:])]
    return ["".join(syl)]


def pinyin(hanzi: str) -> str:
    """Deterministic annotation. No model ever touches this."""
    if not hanzi:
        return ""
    words, marks = [], []
    for tok in seg(hanzi):
        if not tok.strip():
            continue
        if CJK.search(tok):
            words.append(_as_words(tok))
        elif tok in _PUNCT:
            marks.append((sum(len(w) for w in words), _PUNCT[tok]))
        else:
            words.append([tok])
    flat = [s for w in words for s in w]
    flat = _sandhi(flat)
    out, mi = "", 0
    for i, s in enumerate(flat):
        while mi < len(marks) and marks[mi][0] == i:
            out = out.rstrip() + marks[mi][1] + " "
            mi += 1
        out += s + " "
    while mi < len(marks):
        out = out.rstrip() + marks[mi][1] + " "
        mi += 1
    out = re.sub(r"\s+([,.!?;:)])", r"\1", out)
    out = re.sub(r"\s{2,}", " ", out).strip()
    out = re.sub(r"(^|[.!?]\s+)([a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ])",
                 lambda m: m.group(1) + m.group(2).upper(), out)
    return re.sub(r"[a-zāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ']+",
                  lambda m: m.group(0).capitalize()
                  if m.group(0).lower() in _PROPER else m.group(0), out)


# ------------------------------------------------------------------ lexicon
# One index serves two jobs: turning typed pinyin into characters, and
# proposing alternative readings of what the recogniser heard. Both are
# dictionary work, so neither needs a model.
_TONELESS = str.maketrans("āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜüńňǹ",
                          "aaaaeeeeiiiioooouuuuuuuuunnn")
_SYLLABLE = re.compile(
    r"(?:zh|ch|sh|[bpmfdtnlgkhjqxrzcsyw])?"
    r"(?:iang|iong|uang|ueng|ang|eng|ing|ong|uai|uan|üan|ian|iao|ai|ei|ao|ou|"
    r"an|en|er|ia|ie|in|iu|ua|uo|ui|un|üe|ün|a|o|e|i|u|ü|v)r?")

# 一 is the commonest character in the language and it was not here. Nothing
# claimed the sound yi, so the boost went to 以, which is only here because it
# is inside 可以, and man yidian ma came out as 慢以点吗.
#
# Adding the rest of the numbers was tried and reverted. Every character added
# at this weight takes its sound from whatever held it: 二 took 儿, 杯 took 北,
# 万 took 玩, 前 took 钱, 时 took 是, so 半个小时 became 半个小是. The boost is a
# blunt instrument and widening it costs more than it pays. Multi-syllable words
# are already reachable through the dictionary, which is where 三个人, 十块钱 and
# 两杯茶 come from.
CORE = ("我你他她们的了吗呢吧和在有是不没很想要去来看吃喝说做买卖走坐"
        "等给对好大小多少太都也还就会能可以时候今天明天昨天现在人家"
        "钱茶水饭菜车站路口点分块岁年月日上下前后里外东西南北"
        "玩听写读问开关笑累忙快慢近远新旧长短高矮冷热一")

SHORT_OK = {
    "好", "好的", "好了", "好吧", "行", "对", "对的", "是", "是的", "是吗",
    "不是", "没有", "没", "有", "不", "不用", "不要", "要", "可以", "不可以",
    "谢谢", "不客气", "没关系", "对不起", "不好意思", "再见", "拜拜",
    "我也是", "我不知道", "知道了", "真的", "真的吗", "当然", "也许",
    "什么", "为什么", "怎么了", "多少钱", "在哪儿", "几点", "太好了",
    "我很好", "还好", "一般", "差不多", "等一下", "请说", "什么意思",
}

_INDEX = None
_ALTS = {}
_TOTAL = 1.0


def hotwords() -> list:
    try:
        return json.loads((ROOT / "hotwords.json").read_text(encoding="utf-8"))["words"]
    except Exception:
        return []


def lexicon() -> dict:
    """Bare pinyin to characters, built once from the segmenter dictionary."""
    global _INDEX, _TOTAL
    freq = {}
    if _INDEX is not None:
        return _INDEX
    idx = {}
    if HAVE_JIEBA:
        try:
            # jieba loads its dictionary lazily. Without this the frequency
            # table is empty and every score below is meaningless. This was a
            # real bug: it built an empty index whenever nothing had segmented
            # anything yet, which is exactly the case at startup.
            jieba.initialize()
            freq = jieba.dt.FREQ
            if not freq:
                raise RuntimeError("jieba dictionary empty after initialize()")
            words = [(w, f) for w, f in freq.items()
                     if 1 <= len(w) <= 4 and f > 0
                     and all("\u4e00" <= c <= "\u9fff" for c in w)]
            words.sort(key=lambda x: -x[1])
            for w, f in words[:80000]:
                k = "|".join(lazy_pinyin(w))
                if k not in idx or f > idx[k][1]:
                    idx[k] = (w, f)
                # Everything else that sounds the same. One word per sound is
                # right for a first guess and useless for a restaurant: 杯 loses
                # to 北, 碗 to 玩, 份 to 分, 瓶 to 平 and 鸡 to 及, so a learner
                # cannot order a cup of anything. These feed the readings, which
                # the model then chooses between using the conversation. The
                # index still answers with one word; it now also remembers what
                # else it could have said.
                alt = _ALTS.setdefault(k, [])
                if len(alt) < 10 and w not in [x[0] for x in alt]:
                    alt.append((w, f))
        except Exception as e:
            print(f"  dictionary build failed: {e}", flush=True)
    _TOTAL = math.log(sum(f for _, f in idx.values()) + 1) if idx else 1.0
    # Core characters are boosted so each is reachable for its sound. Where two
    # of them share a sound, the commoner one wins.
    #
    # This used to assign in string order, so the last one won. 以 is in there
    # inside 可以 and it replaced 一, which the segmenter ranks at 217830 against
    # 136106, and man yidian ma came out as 慢以点吗. Making the boost a floor
    # instead was tried and was worse: 想 became 向, 慢 became 满, 一杯 became
    # 以北 and 请 became 轻. The boost is doing real work. It just needed to stop
    # being decided by where a character happens to sit in a string.
    core_at = {}
    for ch in CORE:
        k = "|".join(lazy_pinyin(ch))
        rank = freq.get(ch, 0) if isinstance(freq, dict) else 0
        if k not in core_at or rank > core_at[k][1]:
            core_at[k] = (ch, rank)
    for k, (ch, _) in core_at.items():
        idx[k] = (ch, 2_000_000)
    for w in ["西安", "上海", "北京", "成都", "杭州", "南京", "孟买", "印度",
              "新德里", "中国", "香港", "台湾", "重庆", "广州", "深圳"]:
        idx["|".join(lazy_pinyin(w))] = (w, 10 ** 9)
    for w in list(SHORT_OK) + hotwords():
        if w and all("\u4e00" <= c <= "\u9fff" for c in w):
            idx["|".join(lazy_pinyin(w))] = (w, 10 ** 9)
    _INDEX = idx
    return idx


def syllables(text: str) -> list:
    """Any pinyin, spaced or not, toned or not, into bare syllables. An
    apostrophe is a syllable boundary and is honoured: xi'an is two syllables
    and means 西安, xian is one and means 咸."""
    t = text.translate(_TONELESS).lower().replace("v", "ü")
    out = []
    for chunk in [c for c in re.split(r"[^a-zü'’]+", t) if c]:
        if "'" in chunk or "’" in chunk:
            for part in re.split(r"['’]+", chunk):
                if part:
                    out.extend(syllables(part))
            continue
        i = 0
        while i < len(chunk):
            m = _SYLLABLE.match(chunk, i)
            if not m or m.end() == i:
                return []
            out.append(chunk[i:m.end()])
            i = m.end()
    # Erhua, written the way people write it. yidianr is yi dian er, and the
    # dictionary is keyed the second way because that is what the segmenter
    # produces for 一点儿. Without this, man yidianr ma parses into perfectly
    # good syllables, finds nothing, and the whole line comes back as could not
    # read that. Only er legitimately ends in r, so anything else that does is
    # erhua and can be expanded with nothing at risk.
    spread = []
    for syl in out:
        if syl.endswith("r") and syl != "er" and len(syl) > 2:
            spread.append(syl[:-1])
            spread.append("er")
        else:
            spread.append(syl)
    return spread


def lattice(syls: list, k: int = 3) -> list:
    """Best k segmentations as (score, [words]). Log-probability over the
    dictionary, so fewer and commoner words win. Kept separate from readings()
    because the chips need to know where the word boundaries fell, and a joined
    string has thrown that away."""
    idx = lexicon()
    if not idx or not syls or len(syls) > 24:
        return []
    n = len(syls)
    best = [[] for _ in range(n + 1)]
    best[0] = [(0.0, [])]
    for i in range(n):
        if not best[i]:
            continue
        for ln in (1, 2, 3, 4):
            if i + ln > n:
                break
            key = "|".join(syls[i:i + ln])
            hit = idx.get(key)
            if not hit:
                continue
            # The best word for this sound, and the runners up. Without the
            # runners up every reading of a sound is the same word and the
            # alternatives are only ever re-segmentations.
            options = [hit]
            for w, f in _ALTS.get(key, [])[:8]:
                if w != hit[0]:
                    options.append((w, f))
            for word, freq in options[:9]:
                step = math.log(freq + 1) - _TOTAL
                for score, path in best[i][:k]:
                    best[i + ln].append((score + step, path + [word]))
            best[i + ln].sort(key=lambda x: -x[0])
            del best[i + ln][k:]
    return best[n]


def readings(syls: list, k: int = 3) -> list:
    """Best k character strings for a syllable sequence."""
    seen, out = set(), []
    for score, path in lattice(syls, k):
        s = "".join(path)
        if s not in seen:
            seen.add(s)
            out.append((s, score))
    return out[:k]


def best_reading(syls: list) -> str:
    got = readings(syls, 1)
    return got[0][0] if got else ""


_END_PUNCT = {"?": "？", "!": "！", ".": "。", "，": "，", ",": "，"}


def read_typed(typed: str):
    """Split what was typed into syllables, word by word, and report the words
    that could not be read.

    syllables() is all or nothing by design: it returns nothing at all if any
    part of the string is not pinyin. Feeding a whole line through it meant one
    unreadable word killed everything, and the screen said "could not read
    that" without saying which word it meant. Typing back what the screen had
    shown, Meng Boss, failed for exactly this reason, and there was no way to
    find out why."""
    words = [w for w in re.split(r"\s+", (typed or "").strip()) if w]
    good, bad = [], []
    for w in words:
        clean = w.strip(".,!?;:\u3002\uff0c\uff01\uff1f")
        syls = syllables(clean) if clean else []
        if syls:
            good.extend(syls)
        elif clean:
            bad.append(clean)
    if not words:
        return [], []
    # One word typed as a run of syllables with no spaces still goes through
    # syllables() whole, which is the common case and stays exact.
    if len(words) == 1 and not good:
        return [], bad
    return good, bad


def typed_to_hanzi(typed: str) -> str:
    got = best_reading(read_typed(typed)[0])
    if not got:
        return ""
    tail = ""
    for ch in reversed(typed.strip()):
        if ch in _END_PUNCT:
            tail = _END_PUNCT[ch]
            break
        if ch.isalnum():
            break
    return got + tail


# The confusions a learner actually makes, and that a recogniser therefore
# hears. Nasal finals, retroflex initials, and the n/l pair. Alternatives are
# generated across these so that gongyun can reach gongyuan.
# The confusions a learner actually makes, and that a recogniser therefore
# hears. Three families: nasal finals, retroflex versus alveolar, and
# aspiration, which is the one Tamil and Kannada speakers hit hardest because
# the contrast does not work the same way in either language.
_NEAR_FINAL = [("ang", "an"), ("eng", "en"), ("ing", "in"), ("ong", "on"),
               ("uan", "un"), ("üan", "ün"), ("iang", "ian"), ("uang", "uan"),
               ("ie", "ei"), ("uo", "o"), ("iu", "ou"), ("uai", "ai"),
               ("ian", "ie"), ("in", "ing"), ("üe", "ue")]
# Deliberately conservative. x/sh and x/s were tried and removed: they turn
# xǐ into shì, and 是 is frequent enough to swamp every other candidate.
_NEAR_INITIAL = [("zh", "z"), ("ch", "c"), ("sh", "s"), ("n", "l"), ("r", "l"),
                 ("b", "p"), ("d", "t"), ("g", "k"), ("j", "q"), ("z", "c"),
                 ("zh", "ch"), ("g", "h"), ("k", "h")]
_NEAR = _NEAR_FINAL + _NEAR_INITIAL


def _near_syllables(syl: str) -> list:
    out = [syl]
    for a, b in _NEAR_FINAL:
        for x, y in ((a, b), (b, a)):
            if syl.endswith(x) and len(syl) > len(x):
                c = syl[: -len(x)] + y
                if c not in out:
                    out.append(c)
    for a, b in _NEAR_INITIAL:
        for x, y in ((a, b), (b, a)):
            if syl.startswith(x) and len(syl) > len(x):
                c = y + syl[len(x):]
                if c not in out:
                    out.append(c)
    return out


_PARTICLES = "呢了吗吧的地得啊呀哇嘛"


def _sayable(text: str) -> bool:
    """Cheap grammaticality check. Two particles in a row is the giveaway:
    去呢吗 comes out of the lattice but nobody says it."""
    for a, b in zip(text, text[1:]):
        if a in _PARTICLES and b in _PARTICLES and not (a == "的" and b == "话"):
            return False
    return True


def _lev(a: str, b: str) -> int:
    if abs(len(a) - len(b)) > 3:
        return 99
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


_KEY_WORDS = None


def key_words() -> list:
    """The vocabulary worth matching loosely: your word list, the short
    answers, and place names. Small enough to compare against every turn."""
    global _KEY_WORDS
    if _KEY_WORDS is None:
        ws = set(hotwords()) | SHORT_OK | {
            "西安", "上海", "北京", "成都", "杭州", "南京", "孟买", "印度",
            "新德里", "中国", "香港", "台湾", "重庆", "广州", "深圳"}
        _KEY_WORDS = [(w, "".join(lazy_pinyin(w))) for w in ws
                      if w and all("\u4e00" <= c <= "\u9fff" for c in w)]
    return _KEY_WORDS


def near_words(syls: list) -> list:
    """Spans of what was heard that nearly match a word you care about.
    公园 gōngyuán arriving as 共游 gòngyóu is two letters out, which no
    syllable-swap rule reaches but a fuzzy match does."""
    out = []
    for n in (2, 3, 4):
        for i in range(len(syls) - n + 1):
            span = "".join(syls[i:i + n])
            if len(span) < 4:
                continue
            for word, wpy in key_words():
                # Only long words, and only when the lengths nearly agree. A
                # loose gate here produced 吃辣 for 吃了吗 and 很累 for 我很累.
                if len(wpy) < 6 or abs(len(wpy) - len(span)) > 1:
                    continue
                d = _lev(span, wpy)
                if 0 < d <= 2 or (d == 3 and len(wpy) >= 8):
                    out.append((i, n, word, d))
    out.sort(key=lambda x: (x[3], -x[1]))
    return out[:6]


# Written straight in rather than looked up. A lexicon lookup on "la" returns
# 辣, which carries a large boost from your word list and hijacks the slot.
_FINAL_PARTICLES = [("le", "了"), ("ma", "吗"), ("ba", "吧"), ("ne", "呢"),
                    ("a", "啊"), ("ya", "呀"), ("la", "啦"), ("de", "的")]


def alternatives(hanzi: str, k: int = 3) -> list:
    """Other things the same sounds could have been. Candidates come out of the
    dictionary and are filtered for obvious ungrammaticality, which makes them
    plausible rather than guaranteed. They are offered as possible readings,
    not as corrections."""
    syls = [x for x in lazy_pinyin(re.sub(r"[^\u4e00-\u9fff]", "", hanzi))
            if x.strip()]
    if not syls or len(syls) > 12:
        return []
    bare = re.sub(r"[^\u4e00-\u9fff]", "", hanzi)
    seen, scored = {bare}, []

    # The bar is set by the reading of what was actually heard. Setting it by
    # the best variant lets a frequent but wrong guess raise the threshold and
    # push the right answer out.
    base = readings(syls, 1)
    top = base[0][1] if base else None

    for r, sc in readings(syls, k + 2):
        if r not in seen:
            seen.add(r)
            scored.append((r, sc))

    # One syllable at a time, swapped for a near neighbour. Then pairs, because
    # a single mishearing rarely travels alone: 你喜欢辣的 came back as
    # 你习惯了, which is two swaps away, not one.
    work, WORK_CAP = 0, 4000
    singles = []
    for i in range(len(syls)):
        for alt in _near_syllables(syls[i])[1:]:
            trial = syls[:i] + [alt] + syls[i + 1:]
            singles.append((i, trial))
            for r, sc in readings(trial, 1):
                work += 1
                if r not in seen:
                    seen.add(r)
                    scored.append((r, sc))

    singles.sort(key=lambda x: -max([sc for _, sc in readings(x[1], 1)] or [-1e9]))
    for i, trial in singles[:8]:
        if work > WORK_CAP:
            break
        for j in range(len(trial)):
            if j == i:
                continue
            for alt2 in _near_syllables(trial[j])[1:]:
                if work > WORK_CAP:
                    break
                work += 1
                for r, sc in readings(trial[:j] + [alt2] + trial[j + 1:], 1):
                    if r not in seen:
                        seen.add(r)
                        scored.append((r, sc))

    # The last syllable is where a particle lives, and particles are unstressed
    # enough that the recogniser routinely hears something else: 了 le came
    # back as 楼 lóu. Try each particle in that position.
    # Only where a particle could plausibly have been lost: the reading must
    # not already end in one, and the last two syllables must not already form
    # a real word. 很累 and 游玩 are words; 到楼 is not, which is the tell.
    idx_l = lexicon()
    ends_particle = bare and bare[-1] in "".join(ch for _, ch in _FINAL_PARTICLES)
    tail_is_word = len(syls) >= 2 and "|".join(syls[-2:]) in idx_l
    if len(syls) >= 2 and not ends_particle and not tail_is_word:
        stem = readings(syls[:-1], 1)
        if stem:
            stem_text = stem[0][0]
            for rank, (syl, ch) in enumerate(_FINAL_PARTICLES):
                if syl == syls[-1]:
                    continue
                cand = stem_text + ch
                if cand not in seen and _sayable(cand):
                    seen.add(cand)
                    # 了 first, then 吗, then the rest: that is their order of
                    # frequency at the end of a sentence
                    # Scored against the same baseline as everything else.
                    # Using the stem's own score compared a four syllable
                    # reading with a five syllable one, which is meaningless.
                    scored.append((cand, (top if top is not None else 0)
                                   + 1.2 - rank * 0.15))

    # words you use often, matched loosely against what was heard
    for i, n, word, d in near_words(syls):
        left = best_reading(syls[:i]) if i else ""
        right = best_reading(syls[i + n:]) if i + n < len(syls) else ""
        if (i and not left) or (i + n < len(syls) and not right):
            continue
        cand = left + word + right
        if cand not in seen and _sayable(cand):
            seen.add(cand)
            # Ranked above the lattice variants. A match against words you
            # actually use is better evidence than a coincidental
            # re-segmentation: 公园 should beat 共有.
            scored.append((cand, (top if top is not None else 0) + 2.6 - d * 0.3))

    if top is None:
        return []
    # Only readings close to the best one. Without this the list fills with
    # things nobody would say: 取乐吗 for 去了吗.
    margin = float(os.environ.get("ALT_MARGIN", "2.5"))
    scored = [(r, sc) for r, sc in scored if sc >= top - margin and _sayable(r)]
    scored.sort(key=lambda x: -x[1])
    return [r for r, _ in scored[:k]]


# ------------------------------------------------------------------ noise
GHOST_MARKS = ("请不吝", "点赞", "订阅", "转发", "打赏", "明镜", "点点栏目",
               "字幕", "Amara", "志愿者", "小编", "下期再见", "本视频",
               "频道", "关注我", "翻译", "校对", "时间轴", "片尾", "观看")
GHOSTS = {"谢谢观看", "谢谢大家", "拜拜", "下集见"}


def looping(text: str) -> bool:
    t = re.sub(r"[，。！？、,.!?\s]", "", text)
    n = len(t)
    if n < 6:
        return False
    for size in range(2, n // 2 + 1):
        reps = n // size
        if reps >= 2 and t[:size] * reps == t[:size * reps] \
                and size * reps >= n - 1 and (reps >= 3 or n >= 8):
            return True
    for size in range(2, 7):
        if n >= size * 3:
            blocks = [t[i:i + size] for i in range(0, n - size + 1, size)]
            if any(blocks.count(b) >= 3 for b in set(blocks)):
                return True
    return False


def strip_loop(text: str) -> str:
    """Whisper repeats a fragment until it runs out of room. The part before
    the repetition usually is what you said: 我去公司wardwardward... was a real
    turn wearing a broken tail. Returns the head, or empty if nothing is left."""
    t = re.sub(r"[，。！？、\s]", "", text)
    if len(t) < 6:
        return ""
    for size in range(1, 9):
        if len(t) < size * 3:
            break
        for start in range(0, min(len(t) - size * 3 + 1, 24)):
            chunk = t[start:start + size]
            n = 0
            while t[start + n * size: start + (n + 1) * size] == chunk:
                n += 1
            # the tail must dominate, or this is ordinary repetition
            if n >= 4 and n * size > len(t) * 0.5:
                head = t[:start]
                return head if len(head) >= 2 and not is_noise(head) else ""
    return ""


def is_noise(text: str) -> bool:
    t = re.sub(r"[，。！？、,.!?\s]", "", text)
    if not t or not CJK.search(t):
        return True
    # Latin letters sitting inside a Chinese turn. Whisper is English first,
    # and when it loses the thread it falls back into English rather than
    # admitting it has nothing. 蒙 Boss scored 0.45, which was above the line
    # for accepting a turn with a small mark against it, so the word Boss went
    # into the conversation as something that had been said out loud. Whatever
    # it scores, it is a miss. This register has no English in it.
    if re.search(r"[A-Za-z]", text):
        return True
    if t in GHOSTS or any(g in text for g in GHOST_MARKS):
        return True
    if re.search(r"[\u3040-\u30ff\uac00-\ud7af\u0400-\u04ff]", text):
        return True
    if re.search(r"(.)\1{2,}", t) or looping(text):
        return True
    chars = CJK.findall(t)
    if len(chars) >= 6 and len(set(chars)) <= 2:
        return True
    if len(chars) >= 6 and len(set(chars)) / len(chars) < 0.4:
        return True
    return False


# ------------------------------------------------------------------ model
_THINK = {}


async def ollama(model: str, messages: list, schema=None, temp=0.7, predict=200) -> str:
    body = {"model": model, "messages": messages, "stream": False,
            "keep_alive": "30m",
            "options": {"temperature": temp, "num_predict": predict}}
    if schema:
        body["format"] = schema
    async with httpx.AsyncClient(timeout=120) as c:
        if _THINK.get(model) is False:
            r = await c.post(f"{OLLAMA}/api/chat", json=body)
        else:
            r = await c.post(f"{OLLAMA}/api/chat", json={**body, "think": False})
            if r.status_code != 200:
                _THINK[model] = False
                r = await c.post(f"{OLLAMA}/api/chat", json=body)
            else:
                _THINK[model] = True
        r.raise_for_status()
        text = r.json()["message"]["content"]
    return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()


def loads(raw: str, fallback: dict) -> dict:
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw or "", re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return fallback


def num(x, default=0.0, places=3):
    """NaN and Infinity are valid Python floats and invalid JSON. Python writes
    them as bare NaN and Infinity, and the browser rejects the whole response
    with a parse error that says nothing useful. Whisper returns -inf for
    avg_logprob on a degenerate segment, so this is not hypothetical."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    if math.isnan(v) or math.isinf(v):
        return default
    return round(v, places)


def clean_json(obj):
    """Same guarantee, applied to a whole response."""
    if isinstance(obj, dict):
        return {k: clean_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean_json(v) for v in obj]
    if isinstance(obj, float):
        return num(obj)
    return obj


def is_english(t: str) -> bool:
    return bool(t and t.strip()) and not CJK.search(t)


GLOSS_SCHEMA = {"type": "object", "properties": {
    "english": {"type": "string", "description": "English only, Latin letters."}},
    "required": ["english"]}


async def gloss(model: str, hanzi: str) -> str:
    """Never blocks anything. An empty gloss is a cosmetic loss."""
    if not hanzi:
        return ""
    for temp, schema in ((0.1, GLOSS_SCHEMA), (0.3, None)):
        try:
            out = await ollama(model, [
                {"role": "system", "content":
                 "Translate the Chinese into short natural English. Reply with "
                 "the English only. Never reply in Chinese."},
                {"role": "user", "content": hanzi}],
                schema=schema, temp=temp, predict=60)
            if schema:
                out = loads(out, {}).get("english", "")
            out = str(out).strip().strip('"').strip("'").split("\n")[0]
            out = re.sub(r"^(translation|english)\s*[:：]\s*", "", out, flags=re.I)
            if is_english(out):
                return out.strip()
            latin = " ".join(re.findall(r"[A-Za-z][A-Za-z'’,.!?-]*", out)).strip()
            if len(latin) > 2:
                return latin
        except Exception:
            pass
    return ""


# ------------------------------------------------------------------ speech out
def synth(text: str, rate: int = 180):
    if not text or sys.platform != "darwin":
        return None
    key = hashlib.md5(f"{text}|{rate}|{TTS_VOICE}".encode()).hexdigest()[:16]
    path = WORK / f"say_{key}.wav"
    if not path.exists():
        try:
            subprocess.run(["say", "-v", TTS_VOICE, "-r", str(rate), "-o",
                            str(path), "--data-format=LEI16@22050", text],
                           check=True, capture_output=True, timeout=40)
        except Exception:
            return None
    return f"/api/audio/say_{key}"


@app.get("/api/audio/{name}")
def audio(name: str):
    for ext in (".wav", ".webm", ".mp4"):
        p = WORK / f"{name}{ext}"
        if p.exists():
            mt = "audio/wav" if ext == ".wav" else "audio/" + ext[1:]
            return FileResponse(p, media_type=mt)
    return JSONResponse({"error": "gone"}, status_code=404)


# ------------------------------------------------------------------ health
@app.get("/api/health")
async def health():
    """Everything that can be broken, checked in one place. This exists
    because the previous version failed silently and there was no way to
    tell which part had gone."""
    out = {"build": BUILD, "ok": True, "checks": []}

    def add(name, ok, detail="", fatal=True):
        out["checks"].append({"name": name, "ok": bool(ok), "detail": detail,
                              "fatal": fatal})
        if fatal and not ok:
            out["ok"] = False

    add("jieba (word splitting)", HAVE_JIEBA,
        "" if HAVE_JIEBA else "pip install jieba", fatal=False)
    try:
        n = len(lexicon())
        add("pinyin dictionary", n > 1000, f"{n} entries")
    except Exception as e:
        add("pinyin dictionary", False, str(e))

    models = []
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.get(f"{OLLAMA}/api/tags")
        models = sorted(m["name"] for m in r.json().get("models", []))
        add("ollama running", True, f"{len(models)} models")
        add("a model installed", bool(models),
            "" if models else "run: ollama pull qwen3.5:4b")
    except Exception as e:
        add("ollama running", False, f"not reachable at {OLLAMA}")
        add("a model installed", False, str(e))

    try:
        import importlib.util
        found = importlib.util.find_spec("mlx_whisper") is not None
        add("speech recogniser", found,
            WHISPER_REPO if found else "not installed, run ./setup.sh again")
        if found:
            here = asr_cached(WHISPER_REPO)
            add("recogniser downloaded", here, "" if here else
                f"{WHISPER_REPO} is not on disk. Nothing downloads during a "
                f"session, so turns will be refused until you run ./setup.sh.")
            spare = asr_cached(ASR_FALLBACK)
            add("second recogniser downloaded", spare, "" if spare else
                f"{ASR_FALLBACK} is not on disk. A badly heard turn will be "
                f"given up on instead of retried on a steadier model.",
                fatal=False)
    except Exception as e:
        add("speech recogniser", False, str(e))

    if sys.platform == "darwin":
        try:
            have = TTS_VOICE in subprocess.run(["say", "-v", "?"],
                                               capture_output=True, text=True,
                                               timeout=4).stdout
        except Exception:
            have = False
        add(f"{TTS_VOICE} voice", have,
            "" if have else "System Settings, Accessibility, Spoken Content",
            fatal=False)
    else:
        add("speech output", False, "macOS only", fatal=False)

    out["models"] = models
    return out


@app.get("/api/config")
async def config():
    h = await health()
    choices = [dict(c, cached=asr_cached(c["id"])) for c in ASR_CHOICES]
    return {"build": BUILD, "confirm_uncertain": CONFIRM_UNCERTAIN,
            "reply_len": {"min": REPLY_LEN_MIN, "max": REPLY_LEN_MAX},
            "asr_choices": choices, "asr_default": WHISPER_REPO,
            "levels": json.loads((ROOT / "levels.json").read_text(encoding="utf-8")),
            "seeds": json.loads((ROOT / "seeds.json").read_text(encoding="utf-8")),
            "models": sorted(h["models"], key=lambda n: (0 if "qwen" in n.lower() else 1, n)),
            "health": h}


# Twenty-six characters at HSK 2 had no room to notice anything and also answer
# it, so the model answered and dropped the noticing. Raised, and now settable
# from the start screen, because the right number depends on how the learner's
# Mandarin is on the day and that is not something a server can reason about.
REPLY_LEN_MIN = 12
REPLY_LEN_MAX = 90


def level_by_id(lid: str, reply_len: int = 0) -> dict:
    levels = json.loads((ROOT / "levels.json").read_text(encoding="utf-8"))
    got = next((l for l in levels if l["id"] == lid), levels[1])
    if reply_len:
        got = dict(got, max_chars=max(REPLY_LEN_MIN,
                                      min(REPLY_LEN_MAX, int(reply_len))))
    return got


# ------------------------------------------------------------------ persona
def persona_prompt(situation: str, lvl: dict, state: str = "") -> str:
    """Who this person is, and how a conversation works. Nothing about what
    any particular conversation means or where it should go.

    Earlier versions of this carried worked examples about the Great Wall, the
    new terminal and favourite gates, and seeds.json carried, for fifteen
    scenes, what each person knew and where each conversation could travel. All
    of it written by an assistant guessing at scenes it had never been in. A
    model that knows what a waiter is does not need to be told what a waiter
    knows."""
    known = f"\nWhat has been established so far:\n{state}\n" if state else ""
    return f"""You are a real person, mid conversation, speaking Mandarin.

Where you are: {situation}
{known}
Their Chinese is around {lvl['label']}, so you keep it simple without thinking
about it.

Respond naturally to the latest thing they said. Do not repeat a question whose
answer is already evident from the conversation. Do not force the conversation
back onto an earlier thread. You may react, answer, comment, volunteer
information, ask something relevant, or naturally move the conversation
forward.

- {lvl['guidance']}
- Around {lvl['max_chars']} Chinese characters. A little over is fine.
- Never open by handing them their own words back. That is an echo, not a
  reaction.
- Say a thing once.

Never: praise their Chinese, correct them, explain grammar, offer them words,
mention that they are learning, or write anything except simplified characters.

You are having a conversation. That is the whole job."""


# 'reading' comes first on purpose, so it is filled before the reply is written.
#
# Four turns in one session were correct and empty. Told 中辣, medium, by someone
# he does not believe can handle spice, he said he would add spicy chicken.
# Praised for noodles still in the kitchen, he said thank you, we always take
# care. Given an order of three bottles of water for one person, he said
# certainly. Asked to slow down by a passenger who was running late, he said be
# careful. Nothing wrong in any of them, and the interesting thing in every one
# was the gap between what was said and what was expected.
#
# A model asked for a sentence writes a sentence. Asked first what the turn
# means and whether anything about it is worth remarking on, it has somewhere to
# reply from. It also makes the difference visible between not understanding the
# learner and understanding them and having nothing to say, which are different
# faults and were indistinguishable from the outside.
TURN_SCHEMA = {"type": "object", "properties": {
    "reading": {"type": "string",
                "description": "English, one line. What they meant, and "
                               "anything about it worth remarking on."},
    "text": {"type": "string", "description": "Simplified Chinese only."},
    "english": {"type": "string", "description": "English translation, Latin letters only."}},
    "required": ["reading", "text", "english"]}


def clean_reply(text: str, cap: int) -> str:
    text = re.sub(r"[A-Za-z]+", "", text or "")
    text = text.split("\n")[0].strip().strip('"').strip()
    if not CJK.search(text):
        return ""
    if len(CJK.findall(text)) > cap * 1.6:
        keep, n = "", 0
        for part in re.split(r"(?<=[。！？])", text):
            if n and n + len(CJK.findall(part)) > cap * 1.6:
                break
            keep += part
            n += len(CJK.findall(part))
        text = keep or text[: int(cap * 1.6)]
    return text.strip()


async def say_turn(model, messages, lvl, fallback="嗯。"):
    last_error = ""
    for temp in (0.85, 0.5):
        try:
            out = await ollama(model, messages, schema=TURN_SCHEMA, temp=temp)
        except Exception as e:
            last_error = f"{type(e).__name__}: {e}"
            print(f"  model call failed: {last_error}", flush=True)
            continue
        d = loads(out, {})
        text = clean_reply(d.get("text", ""), lvl["max_chars"])
        if text:
            en = (d.get("english") or "").strip()
            if not is_english(en):
                en = await gloss(model, text)
            return {"text": text, "pinyin": pinyin(text), "english": en,
                    "reading": (d.get("reading") or "").strip()[:300],
                    "audio": synth(text)}
    if last_error:
        return {"error": last_error}
    print("  model replied but produced no usable Chinese", flush=True)
    return {"text": fallback, "pinyin": pinyin(fallback), "english": "",
            "audio": synth(fallback), "degraded": True}


def to_messages(persona, history, last=None):
    """Clarifications are dropped except the most recent. Otherwise a run of
    bad audio fills the model's history with its own re-asks and it starts
    behaving as though the conversation is nothing but repetition."""
    kept, seen_clar = [], False
    for m in reversed(history):
        if m.get("kind") == "clarification":
            if seen_clar:
                continue
            seen_clar = True
        kept.append(m)
    history = list(reversed(kept))
    msgs = [{"role": "system", "content": persona}]
    for m in history[-8:]:
        msgs.append({"role": "user" if m["role"] == "you" else "assistant",
                     "content": m["text"]})
    if last:
        msgs.append({"role": "user", "content": last})
    return msgs


@app.post("/api/open")
async def open_line(situation: str = Form(...), level: str = Form("hsk2"),
                    model: str = Form(...), reply_len: int = Form(0)):
    try:
        return await _open(situation, level, model, reply_len)
    except Exception as e:
        print(f"  open failed: {type(e).__name__}: {e}", flush=True)
        return {"error": f"{type(e).__name__}: {e}"}


async def _open(situation, level, model, reply_len=0):
    lvl = level_by_id(level, reply_len)
    msgs = [{"role": "system", "content": persona_prompt(situation, lvl)},
            {"role": "user", "content":
             "Say the first thing you would say, to open the conversation. "
             "Give them something easy to answer. "
             "JSON: 'reading' is one line of English on what you are opening "
             "with and why, 'text' is your line in Chinese characters, "
             "'english' is its English translation."}]
    return await say_turn(model, msgs, lvl, "你好！")


@app.post("/api/reply")
async def reply(said: str = Form(...), model: str = Form(...),
                level: str = Form("hsk2"), situation: str = Form(""),
                history: str = Form("[]"), state: str = Form(""),
                steer: str = Form(""), reply_len: int = Form(0)):
    try:
        return await _reply(said, model, level, situation, history, state, steer,
                            reply_len)
    except Exception as e:
        print(f"  reply failed: {type(e).__name__}: {e}", flush=True)
        return {"error": f"{type(e).__name__}: {e}"}


async def _reply(said, model, level, situation, history, state="",
                 steer="", reply_len=0):
    t0 = time.time()
    lvl = level_by_id(level, reply_len)
    convo = json.loads(history) if history else []
    mine = next((m["text"] for m in reversed(convo) if m.get("role") == "them"), "")
    # The instruction names both sides of the exchange. A reply that is good
    # Mandarin and has nothing to do with the turn is the failure being guarded
    # against here, and it happened because the model was handed a list of
    # strings and asked to continue it.
    ask = (f"They just said: {said}\n\n"
           + (f"You had just said: {mine}\n\n" if mine else "")
           + "First, in 'reading': what did they mean, and is anything about "
             "it worth remarking on? Something surprising, something that does "
             "not add up, something you have an opinion about, something they "
             "have got slightly wrong. Often there is, and it is usually the "
             "gap between what they said and what you were expecting.\n\n"
             "Then reply, in 'text'. If your reading found something, that is "
             "what your reply is about. Otherwise answer plainly. React, "
             "answer, comment, volunteer something, ask something relevant, or "
             "move the conversation on, whichever a person would do here.\n\n"
             "JSON: 'reading' in English, 'text' in Chinese characters, "
             "'english' its English translation.")

    theirs = [m.get("text", "") for m in convo if m.get("role") == "them"]
    if theirs:
        ask += ("\n\nYou have already said these. Do not say any of them again, "
                "in any words, and do not ask any of these again:\n"
                + "\n".join(f"- {t}" for t in theirs[-6:])
                + "\nIf they have answered your question, that question is "
                  "finished. Move to something else that fits where you are.")
    if steer:
        # The learner steering the conversation. Their instruction outranks
        # everything the other person felt like saying, because they are the
        # one practising and they know what they want to practise.
        ask += (f"\n\nTHE DIRECTION FOR THIS TURN: {steer}\n"
                f"Take the conversation there now, in character. This matters "
                f"more than anything else you were going to say.")
    msgs = to_messages(persona_prompt(situation, lvl, state), convo, ask)
    out = await say_turn(model, msgs, lvl, "嗯，是吗？")

    # Checked rather than asked for. A line in the brief saying never ask the
    # same thing twice does not survive a model rebuilding the scene each turn,
    # and one session produced three tellings of the new terminal being big and
    # three askings of whether he had been here before, in five turns.
    # One retry, and only when it fires.
    # Everything anyone has actually said, plus the scene itself. A place name
    # outside this was invented.
    bad = reply_problems(out.get("text", ""), theirs, said)
    if bad:
        print("  reply sent back: " + "; ".join(b[:60] for b in bad), flush=True)
        retry = msgs + [
            {"role": "assistant", "content": out.get("text", "")},
            {"role": "user", "content":
             "That will not do.\n\n" + "\n\n".join(bad)
             + "\n\nSay it again. React to what they just said, then ask them "
               "one thing about themselves. JSON: 'text' in Chinese characters, "
               "'english' its English translation."}]
        second = await say_turn(model, retry, lvl, "")
        left = reply_problems(second.get("text", ""), theirs, said) \
            if second.get("text") else bad
        if second.get("text") and len(left) < len(bad):
            out, bad = second, left
        out["retried"] = True

        # A reply already known to be bad does not go out. Two sessions ran
        # 你对历史感兴趣吗 twice and 那您去过吗 twice, both of them detected and
        # both of them sent anyway, because the retry was no better and the
        # first one was kept. If the trouble is the question, the reaction on
        # its own is a smaller turn and an honest one.
        if bad:
            trimmed = drop_question(out.get("text", ""))
            if trimmed and not reply_problems(trimmed, theirs, said):
                print(f"  question dropped, reaction kept: {trimmed}", flush=True)
                out = dict(out, text=trimmed, pinyin=pinyin(trimmed),
                           english="", trimmed=True)
            out["still_flagged"] = [b[:80] for b in bad]

    out["timings"] = {"reply": int((time.time() - t0) * 1000)}
    record("reply", said=said, their_last=mine, state=state,
           reading=out.get("reading", ""),
           problems=bad, retried=bool(bad),
           text=out.get("text", ""), pinyin=out.get("pinyin", ""),
           english=out.get("english", ""), situation=situation, level=level,
           ms=out["timings"]["reply"])
    return out


# A no is the answer that gets ignored. "Have you flown from here before?"
# answered with 不，我没有 was followed by "which gate do you like best?", which
# only makes sense if the answer had been yes. Cheap to spot and worth spotting
# deterministically, because it is the shape that breaks most often: the model
# carries on with the topic instead of with the proposition.
# Words that carry no topic. Two questions sharing only these are not the same
# question.
_EMPTY = set("的了吗呢吧和在有是不没很太都也还就会能你我他她它们这那个"
             "一二三四五六七八九十几多少什么怎么谁哪呀啊哦嗯啦么之其于与"
             "对好来去说做要想能可以真挺又再还是不是")


def content_words(text: str) -> set:
    """The words in a line that carry its subject."""
    bare = re.sub(r"[^\u4e00-\u9fff]", "", text or "")
    if not bare:
        return set()
    try:
        import jieba
        jieba.initialize()
        toks = [w for w in jieba.cut(bare) if w]
    except Exception:
        toks = list(bare)
    out = set()
    for w in toks:
        if len(w) >= 2 and not all(c in _EMPTY for c in w):
            out.add(w)
        elif len(w) == 1 and w not in _EMPTY:
            out.add(w)
    return out


def repeats_itself(new: str, previous: list) -> str:
    """Is this line something the same person has already said? Returns the
    line it repeats, or empty.

    Read as a conversation, one session went: the new terminal is nice, the new
    terminal is very big, the new airport is indeed big. And: is this your first
    time here, have you flown this flight before, have you taken other flights
    before. Three askings of one question and three tellings of one fact, in
    five turns.

    A rule in the brief saying never ask the same thing twice does not survive a
    model rebuilding the scene each turn. This checks."""
    bare = re.sub(r"[^\u4e00-\u9fff]", "", new or "")
    if len(bare) < 4:
        return ""
    new_words = content_words(new)
    is_question = any(m in (new or "") for m in ("？", "?", "吗", "呢"))
    for old in previous:
        old_bare = re.sub(r"[^\u4e00-\u9fff]", "", old or "")
        if len(old_bare) < 4:
            continue
        # a four character run said twice is a repeat, whatever else changed
        grams = {old_bare[i:i + 4] for i in range(len(old_bare) - 3)}
        if any(bare[i:i + 4] in grams for i in range(len(bare) - 3)):
            return old
        # two questions about the same things are the same question
        if is_question and any(m in old for m in ("？", "?", "吗", "呢")):
            old_words = content_words(old)
            if new_words and old_words:
                shared = len(new_words & old_words)
                if shared >= 2 or shared / max(len(new_words), 1) >= 0.5:
                    return old
    return ""


_Q_MARK = ("？", "?", "吗", "呢")
# 去印度啊？ is not a question, it is someone repeating what they just heard.
# So is 你说呢就是不知道呀。 A clause that ends on one of these particles is an
# echo, whatever punctuation follows it.
_ECHO_END = "啊呀哦噢欸嗯呗嘛"
_ASKS = ("哪", "几", "多少", "什么", "怎么", "谁", "为什么", "多久", "多大")
# Tag questions. Reactions with a question mark attached, and never the thing
# the turn is actually asking.
_TAGS = {"好吗", "是吗", "对吗", "行吗", "好不好", "是不是", "对不对", "好吧",
         "是吧", "对吧", "真的吗", "可以吗"}


def questions_in(text: str) -> list:
    """The real question clauses in a line. Echoes and tags are not questions."""
    out = []
    # Split on the question mark too, keeping it, or 去印度啊？那肯定很热闹 stays
    # in one piece and the echo at the front is never seen for what it is.
    for part in re.split(r"(?<=[？?])|[。！，、,.!\n]", text or ""):
        if not part:
            continue
        bare = re.sub(r"[^\u4e00-\u9fff]", "", part)
        if not bare or not any(m in part for m in _Q_MARK):
            continue
        if bare in _TAGS:
            continue
        # An echo particle at the end only makes it an echo if there is no
        # question word in it. 从哪座城市出发呀 ends in 呀 and is plainly a
        # question. 吗 and 呢 are left out of that test on purpose, because
        # they turn up inside quotes of what the other person said.
        if bare[-1] in _ECHO_END and not any(w in bare for w in _ASKS):
            continue
        out.append(bare)
    return out


def _lcs(a: str, b: str) -> int:
    if not a or not b:
        return 0
    row = [0] * (len(b) + 1)
    best = 0
    for ca in a:
        prev, row = row, [0] * (len(b) + 1)
        for j, cb in enumerate(b, 1):
            if ca == cb:
                row[j] = prev[j - 1] + 1
                best = max(best, row[j])
    return best


def echoes_learner(reply: str, said: str) -> bool:
    """Does this reply open by handing the learner their own words back?

    Every turn of two sessions had the same shape: 喜欢长城啊，那您去过吗？
    想起长城啊，那您去过吗？ 请你告诉我？你有什么想分享的吗？ That last one echoed
    please tell me and then asked what they would like to share.

    It is in the brief. A short reaction to what they just said was read as
    repeat their words with a particle on the end, and five builds of checks
    below it made the shape compulsory."""
    first = ""
    for part in re.split(r"[，。！？,.!?\n]", reply or ""):
        bare = re.sub(r"[^\u4e00-\u9fff]", "", part)
        if bare:
            first = bare
            break
    heard = re.sub(r"[^\u4e00-\u9fff]", "", said or "")
    if len(first) < 2 or not heard:
        return False
    n = _lcs(first, heard)
    # A shared place name is two characters and is not an echo, so the ratio
    # rule needs three. 孟买很远 after 我是从孟买来的 is a person reacting.
    if n >= 3 and n / len(first) >= 0.5:
        return True
    # Their words plus a particle. 喜欢长城啊 after 我喜欢去长城.
    return n >= 2 and first[-1] in "啊呀哦噢欸嗯呗嘛"


def asked_recently(previous: list, n: int = 2) -> int:
    """How many of this person's last n turns ended in a question."""
    return sum(1 for t in previous[-n:] if questions_in(t))


def drop_question(text: str) -> str:
    """The line with its question clauses removed. What is left is a person
    reacting and then stopping, which is a thing people do."""
    keep = []
    for part in re.split(r"(?<=[。！？?!，,])", text or ""):
        bare = re.sub(r"[^\u4e00-\u9fff]", "", part)
        if not bare:
            continue
        if any(m in part for m in _Q_MARK) and bare not in _TAGS:
            continue
        keep.append(part)
    out = "".join(keep).strip().strip("，,")
    if not out or len(re.findall(r"[\u4e00-\u9fff]", out)) < 2:
        return ""
    if out[-1] not in "。！？!?":
        out += "。"
    return out


def reply_problems(text: str, previous: list, said: str = "") -> list:
    """What is wrong with this reply, in words the model can act on.

    All three of these came out of one session read as a conversation rather
    than as turns. Checked instead of asked for, because a bullet in a list of
    seven does not survive a model rebuilding the scene each turn."""
    bad = []

    again = repeats_itself(text, previous)
    if again:
        bad.append(f"You have already said this. It is too close to: {again}. "
                   f"Do not return to that subject at all.")

    if said and echoes_learner(text, said):
        bad.append("You have opened by saying their own words back to them. "
                   "React to what they said, do not repeat it. Say what you "
                   "think of it, or what it reminds you of, or something about "
                   "yourself.")

    qs = questions_in(text)
    if qs and asked_recently(previous, 2) >= 2:
        bad.append("You have ended your last two turns with a question and this "
                   "is a third. Do not ask anything this time. Say something "
                   "instead: what you think, something about yourself, "
                   "something about where you are.")
    if len(qs) > 1:
        bad.append(f"That is {len(qs)} questions in one turn. Ask one. Keep "
                   f"the one they can answer most easily and drop the rest.")

    return bad


STATE_SCHEMA = {"type": "object", "properties": {
    "state": {"type": "string",
              "description": "English. At most four short lines."}},
    "required": ["state"]}


@app.post("/api/state")
async def state_update(model: str = Form(...), situation: str = Form(""),
                       history: str = Form("[]"), state: str = Form(""),
                       turn: int = Form(0)):
    """What has been established, kept short and kept visible.

    Not a summary of the dialogue, which the history already is. A record of
    what is now true: where you are, what has been agreed, what this person has
    decided about you. The driver asking where the airport is happened because
    nothing carried that forward.

    Runs while the reply is being spoken, so it costs no waiting. It is shown
    in diagnostics, because a state that is wrong is worse than no state and
    the only defence is being able to see it."""
    try:
        convo = json.loads(history) if history else []
        if len(convo) < 2:
            return {"state": state, "turn": turn}
        recent = "\n".join(f"{'them' if m.get('role') == 'them' else 'you'}: "
                            f"{pinyin(m.get('text', ''))}" for m in convo[-6:])
        raw = await ollama(model, [
            {"role": "system", "content":
             "You keep a short record of what is now true in a conversation. "
             "Facts only, in English, at most four short lines, each one a "
             "plain statement like 'from India' or 'going to the airport' or "
             "'has been here before'.\n\n"
             "Only what was actually said. Not what it suggests, not what "
             "follows from it, not what would be reasonable. If someone says "
             "they are going to the airport, that is 'going to the airport', "
             "and it is not 'travelling for work' or 'in a hurry'. A record "
             "that is wrong is worse than an empty one, because everything "
             "after it is built on it.\n\n"
             "Revise the record you are given rather than starting again."},
            {"role": "user", "content":
             f"Situation: {situation}\n\nRecord so far:\n{state or '(empty)'}"
             f"\n\nLatest turns:\n{recent}\n\nJSON: 'state'."}],
            schema=STATE_SCHEMA, temp=0.0, predict=120)
        got = json.loads(raw).get("state", "")
        # The turn this was computed from travels back with it. These
        # run while a reply is being spoken and two can be in flight at
        # once, and an older one landing last would quietly undo the
        # newer record.
        return {"state": str(got)[:400], "turn": turn}
    except Exception as e:
        print(f"  state update skipped: {type(e).__name__}: {e}", flush=True)
        return {"state": state, "turn": turn}


@app.post("/api/clarify")
async def clarify(model: str = Form(...), level: str = Form("hsk2"),
                  situation: str = Form(""), history: str = Form("[]"),
                  state: str = Form(""), reply_len: int = Form(0)):
    try:
        return await _clarify(model, level, situation, history, state, reply_len)
    except Exception as e:
        print(f"  clarify failed: {type(e).__name__}: {e}", flush=True)
        return {"error": f"{type(e).__name__}: {e}"}


async def _clarify(model, level, situation, history, state="", reply_len=0):
    """Targeted clarification. The literature is clear that asking about the
    specific thing beats a bare 'what?', so this re-asks its own question in
    simpler words rather than just saying it did not hear."""
    lvl = level_by_id(level, reply_len)
    convo = json.loads(history) if history else []
    mine = next((m["text"] for m in reversed(convo)
                 if m.get("role") == "them" and m.get("kind") != "clarification"), "")
    # The exact question, handed back. Told to re-ask it and given no room to
    # do anything else. Asked to "ask your own last question again" without the
    # question in front of it, the model invented a new one: the exit became
    # the restroom, and the thread was gone. A turn that was not heard is an
    # interruption to where you are, not permission to move on.
    if mine:
        ask = (f"You did not catch what they said.\n\n"
               f"You had just asked: {mine}\n\n"
               f"Say you did not catch it, in three or four words. Then ask "
               f"that same question again, more simply. Same question. Do not "
               f"ask about anything else and do not move the conversation on. "
               f"JSON: 'text' in Chinese characters, 'english' its English "
               f"translation.")
    else:
        ask = ("(You did not catch what they said. Say so in three or four "
               "words, then ask one easy question. JSON: 'text' in Chinese "
               "characters, 'english' its English translation.)")
    msgs = to_messages(persona_prompt(situation, lvl, state), convo, ask)
    out = await say_turn(model, msgs, lvl, "什么？没听清。")
    out["kind"] = "clarification"
    return out


# ------------------------------------------------------------------ record
# One line per turn, so a bad turn can be argued about afterwards instead of
# remembered. Without the layers separated in the record, a bug gets fixed in
# the wrong one: the chips looked like a chip problem and were a resolver
# problem, and the driver changing the subject looked like a persona problem
# and was one line in the clarification prompt.
SESSION = WORK / "session.jsonl"


def record(kind: str, **fields):
    try:
        fields["kind"] = kind
        fields["at"] = int(time.time())
        with SESSION.open("a", encoding="utf-8") as f:
            f.write(json.dumps(fields, ensure_ascii=False) + "\n")
    except Exception:
        pass                       # a diagnostic must never break a turn


@app.get("/api/session")
def session_log(limit: int = 200):
    """The turns of this session, newest last. Hand this back when something
    went wrong and the layer it went wrong in is already in it."""
    try:
        lines = SESSION.read_text(encoding="utf-8").strip().split("\n")
    except Exception:
        return {"turns": []}
    out = []
    for line in lines[-limit:]:
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return {"turns": out, "file": str(SESSION)}


@app.post("/api/session/clear")
def session_clear():
    try:
        SESSION.unlink()
    except Exception:
        pass
    return {"cleared": True}


# ------------------------------------------------------------------ spelling
# Which characters a typed line spells, here.
#
# This is not the layer that was pulled out of the project. That one was asked
# what the learner meant, had no access to the audio, and wrote whole sentences
# nobody had said. This one is handed syllables the learner typed with their own
# fingers, which are not evidence of anything, they are the thing itself. Its
# answer is read back into pinyin and compared, and anything that does not spell
# out to exactly those syllables is thrown away and the dictionary answers
# instead. There is no sentence it can write that the learner did not type.
#
# It exists because the dictionary cannot do this and no amount of tuning has
# made it. One word per sound gives 一北茶 for yi bei cha, 一玩面条 for yi wan
# miantiao, 三平水 for san ping shui and 记得面条 for ji de miantiao. Widening it
# to the runners up was tried three times: 鸡 is the fifteenth commonest word
# for the sound ji, so a learner ordering chicken noodles is not reachable by
# frequency at any beam width. Which character goes with which is a language
# question, and there is a language model in the building.

SPELL_SCHEMA = {"type": "object", "properties": {
    "hanzi": {"type": "string",
              "description": "simplified characters, one per syllable given, "
                             "no punctuation"}},
    "required": ["hanzi"]}


def spells_out(hanzi: str, syls: list) -> bool:
    """Does this string of characters read as exactly these syllables?"""
    bare = re.sub(r"[^\u4e00-\u9fff]", "", hanzi or "")
    if not bare:
        return False
    got = lazy_pinyin(bare)
    if got == syls:
        return True
    # 儿 is written er by the segmenter and is a suffix on the syllable before
    # it when someone types nar or yidianr. Both spellings are the same word.
    joined, i = [], 0
    while i < len(got):
        if i + 1 < len(got) and got[i + 1] == "er":
            joined.append(got[i] + "r")
            i += 2
        else:
            joined.append(got[i])
            i += 1
    return joined == syls


async def spell(model, typed: str, syls: list, convo: list, situation: str) -> str:
    """Characters for these syllables, or empty if it could not."""
    if not syls or len(syls) > 20:
        return ""
    last = next((m.get("text", "") for m in reversed(convo)
                 if m.get("role") == "them"), "")
    recent = "\n".join(f"{'them' if m.get('role') == 'them' else 'you'}: "
                        f"{m.get('text', '')}" for m in convo[-4:])
    try:
        raw = await ollama(model, [
            {"role": "system", "content":
             "You write out pinyin as Chinese characters. Someone learning "
             "Mandarin typed the syllables below and you give the characters "
             "they spell.\n\n"
             "One character per syllable, in the same order, nothing added and "
             "nothing left out. No punctuation, no pinyin, no explanation.\n\n"
             "Where a syllable could be several characters, the conversation "
             "decides. In a noodle shop ji de miantiao is 鸡的面条 and not "
             "记得面条; yi bei cha is 一杯茶 and not 一北茶; san ping shui is "
             "三瓶水 and not 三平水.\n\n"
             "If the syllables do not spell anything sensible, write out the "
             "most ordinary reading of them anyway. Do not correct their "
             "grammar and do not write a better sentence than they typed."},
            {"role": "user", "content":
             f"Situation: {situation}\n"
             + (f"Recent turns:\n{recent}\n" if recent else "")
             + (f"The other person just said: {last}\n" if last else "")
             + f"\nSyllables: {' '.join(syls)}\n"
               f"They typed: {typed}\n\nJSON: 'hanzi'."}],
            schema=SPELL_SCHEMA, temp=0.0, predict=60)
        got = re.sub(r"[^\u4e00-\u9fff]", "", json.loads(raw).get("hanzi", ""))
    except Exception as e:
        print(f"  spelling unavailable: {type(e).__name__}: {e}", flush=True)
        return ""
    if not got:
        return ""
    if not spells_out(got, syls):
        print(f"  spelling rejected: {got} is not {' '.join(syls)}", flush=True)
        return ""
    return got


# ------------------------------------------------------------------ resolve
# The resolver chooses. It never writes.
#
# An earlier version of this project put a language model between the learner
# and the conversation and asked it to work out what had been meant. It had no
# access to the audio and every incentive to write a better sentence than the
# one that was said, so it did: 你好,去啦吗? came back as 你好，要去机场了吗？ and
# the conversation carried on as though that had been said. About a dozen
# builds were lost before it was pulled out.
#
# This is that layer, brought back under one hard constraint. It is handed a
# numbered list of utterances that the sounds already support, and it returns a
# number. There is no field in its output that a sentence could go into. It can
# be wrong about which candidate, and it cannot invent one, which is the
# failure that cost the time.
#
# Candidates come from the recogniser and from the dictionary walking the
# syllables the recogniser produced. Context ranks them. Context never adds to
# them.

# Three questions, three fields, and still nowhere to write a sentence.
#
# The two-field version could not tell these apart, and they need different
# answers:
#
#   none of the alternatives beats what was heard
#   what was heard is not a thing anyone would say
#
# Both came back as -1, and -1 meant a dead end. So 我的行李不重, heard correctly
# at 0.50 in direct answer to 你行李重不重, was thrown away twice. The recogniser
# had done its job and the layer above refused to believe it.
RESOLVE_SCHEMA = {"type": "object", "properties": {
    "pick": {"type": "integer",
             "description": "index of the best option, or -1 if none is better "
                            "than option 0"},
    "natural": {"type": "boolean",
                "description": "true if option 0 is something a person would "
                               "actually say in Mandarin"},
    "certain": {"type": "boolean",
                "description": "true if the choice clearly fits both the sounds "
                               "and what was just asked"}},
    "required": ["pick", "natural", "certain"]}

# Above this the turn is taken as heard and no resolver call is made at all.
# Most turns land here, and a turn that lands here costs nothing beyond the
# recogniser.
#
# The bar depends on how much was said, because the decoder score means
# different things at different lengths. A decoder that has lost the thread
# invents short things: Boss, 我估计到, 你告诉我. It does not invent 我住在孟买你呢
# and hold it together for seven characters. Two correct answers were thrown
# away at 0.50 and 0.58 while a flat bar of 0.62 sent them to a model that then
# called them unnatural, which they plainly were not.
#
# Measured against every turn of three real sessions: with the bar at 0.62 for
# four characters or fewer and 0.46 above that, thirteen of fourteen land where
# they should, and the fourteenth costs a resolver call rather than an error.
RESOLVE_ABOVE = float(os.environ.get("RESOLVE_ABOVE", "0.62"))
RESOLVE_ABOVE_LONG = float(os.environ.get("RESOLVE_ABOVE_LONG", "0.46"))
LONG_ENOUGH = int(os.environ.get("LONG_ENOUGH", "5"))


def free_pass(text: str) -> float:
    """The confidence at which this much speech is taken as heard."""
    n = len(re.findall(r"[\u4e00-\u9fff]", text or ""))
    return RESOLVE_ABOVE_LONG if n >= LONG_ENOUGH else RESOLVE_ABOVE


async def resolve(model, sounds, options, convo, situation):
    """Returns (pick, certain, natural).

    pick    index of the best option, or -1 when nothing beats option 0
    certain the choice plainly fits the sounds and the question
    natural option 0 is a thing a person would say

    -1 is not a rejection. It means what was heard already stands. A rejection
    is natural=False, and that is the only route to a dead end."""
    if not options:
        return -1, False, False
    if len(options) == 1:
        # Nothing to choose between. Whether it is a real utterance is still
        # worth asking, and it is the only question left.
        pass
    last = next((m["text"] for m in reversed(convo) if m.get("role") == "them"), "")
    numbered = "\n".join(f"{i}. {pinyin(o)}  ({o})" for i, o in enumerate(options))
    sys_msg = (
        "A learner of Mandarin said something. A speech recogniser heard it, "
        "and option 0 below is what it heard. The other options are readings "
        "of the same syllables, produced by walking a dictionary over them.\n\n"
        "Answer three things.\n\n"
        "natural: is option 0 something a person would actually say? Real "
        "spoken Mandarin, not a string of dictionary words. 我的行李不重 is "
        "natural. 要面笑前菜辣里 is not, and neither is 不是有面在洗手间. This is "
        "the one that matters most.\n\n"
        "pick: which option best explains the sounds and answers what was just "
        "said. Option 0 is what was actually heard, so it starts ahead. Choose "
        "another only when it fits the sounds just as well and makes clearly "
        "better sense as a reply here. Return -1 when nothing beats option 0.\n\n"
        "certain: true when your choice plainly fits both the sounds and the "
        "question. A sentence that directly answers what was just asked is a "
        "strong signal, even when the recogniser was unsure of itself.\n\n"
        "You cannot write a sentence. You can only answer these three.")

    user = (f"Situation: {situation}\n"
            f"The other person just said: {pinyin(last) if last else '(nothing yet)'}\n"
            f"Sounds heard: {sounds}\n\n"
            f"Options:\n{numbered}\n\n"
            "JSON: 'pick' is the number, 'certain' is true or false.")
    try:
        raw = await ollama(model, [{"role": "system", "content": sys_msg},
                                   {"role": "user", "content": user}],
                           schema=RESOLVE_SCHEMA, temp=0.0, predict=40)
        got = json.loads(raw)
        if "pick" not in got:
            raise ValueError("resolver returned no pick")
        pick = int(got["pick"])
        natural = bool(got.get("natural", True))
        certain = bool(got.get("certain", False))
    except Exception as e:
        print(f"  resolver unavailable: {type(e).__name__}: {e}", flush=True)
        # A resolver that cannot be reached must not swallow the turn. What the
        # recogniser heard stands, marked as uncertain.
        return 0, False, True
    if pick >= len(options):
        pick = -1
    return pick, certain, natural


def candidate_pool(heard: str, k: int = 4) -> list:
    """Utterances the sounds support, best first. Built from what the
    recogniser produced and from the dictionary walking the same syllables.
    Nothing here comes from the conversation."""
    bare = re.sub(r"[^\u4e00-\u9fff]", "", heard or "")
    if not bare:
        return []
    out = [bare]
    # the short-answer snap, kept because the tests prove it earns its place
    sy = lazy_pinyin(bare)
    for cand in SHORT_OK:
        if sy and lazy_pinyin(cand) == sy and cand != bare:
            out.append(cand)
            break
    for a in alternatives(bare, k):
        if a not in out:
            out.append(a)
    return out[:k + 1]


# ------------------------------------------------------------------ listen
def build_primer(convo: list) -> str:
    """A short prompt, because a long one gets echoed back. Short answers are
    always in it, since two syllables give the decoder nothing to work with.
    The rest is chosen for relevance to what is being talked about: after the
    other person mentions noodles, food words are far likelier than airports."""
    if PRIMER_WORDS <= 0:
        return "以下是普通话的日常对话。"

    always = ["对", "好的", "是啊", "没有", "我也是", "不是", "喜欢"]
    pool = [w for w in hotwords() if w not in always]

    recent = "".join(m.get("text", "") for m in convo[-3:])
    topical = [w for w in pool if any(ch in recent for ch in set(w))][:5]

    words = (always + topical)[:PRIMER_WORDS]
    parts = ["以下是普通话的日常对话。", "可能出现的词：" + "、".join(words) + "。"]
    last = next((m["text"] for m in reversed(convo) if m["role"] == "them"), "")
    if last:
        parts.append(f"对方刚说：{last[:24]}")
    return "".join(parts)[:PRIMER_CHARS]


@app.post("/api/listen")
async def listen(audio: UploadFile, model: str = Form(...),
                 level: str = Form("hsk2"), situation: str = Form(""),
                 history: str = Form("[]"), asr: str = Form("")):
    try:
        return clean_json(await _listen(audio, model, level, situation,
                                        history, asr or WHISPER_REPO))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"empty": True, "why": f"{type(e).__name__}: {e}"}


def decode_audio(src: Path, dst: Path) -> dict:
    """Convert to 16kHz mono WAV ourselves and measure it, rather than handing
    a browser container to the recogniser and hoping.

    This exists because the recogniser was producing 各位 and repetition loops
    with a healthy microphone meter, which is what Whisper does when it cannot
    find speech. Without measuring the audio that actually reaches it, there
    was no way to tell a bad recording from a bad recogniser."""
    # Trim silence from both ends. A short burst of speech surrounded by
    # silence is the shape that makes Whisper invent 各位 and fall into
    # repetition loops, and push-to-talk produces exactly that shape.
    trim = ("silenceremove=start_periods=1:start_threshold=-45dB:"
            "start_silence=0.05:detection=rms,areverse,"
            "silenceremove=start_periods=1:start_threshold=-45dB:"
            "start_silence=0.05:detection=rms,areverse")
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
             "-i", str(src), "-ac", "1", "-ar", "16000",
             "-af", trim, "-f", "wav", str(dst)],
            check=True, capture_output=True, timeout=30)
        if not dst.exists() or dst.stat().st_size < 2000:
            raise subprocess.CalledProcessError(1, "trim produced nothing")
    except FileNotFoundError:
        return {"ok": False, "why": "ffmpeg is not installed, run ./setup.sh again"}
    except Exception:
        # Trimming can remove everything on a very quiet recording, and it also
        # fails on a file that is not audio at all. Try once without the
        # filter, then give up with a message rather than an exception.
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                 "-i", str(src), "-ac", "1", "-ar", "16000", "-f", "wav", str(dst)],
                check=True, capture_output=True, timeout=30)
        except FileNotFoundError:
            return {"ok": False, "why": "ffmpeg is not installed, run ./setup.sh again"}
        except subprocess.CalledProcessError as e:
            tail = (e.stderr or b"").decode("utf8", "ignore").strip().split("\n")[-1][:160]
            return {"ok": False, "why": f"the recording could not be decoded: {tail}"}
        except Exception as e:
            return {"ok": False, "why": f"decoding failed: {type(e).__name__}: {e}"}

    try:
        import wave
        import audioop
        with wave.open(str(dst), "rb") as w:
            frames = w.getnframes()
            rate = w.getframerate()
            raw = w.readframes(frames)
            width = w.getsampwidth()
        secs = frames / float(rate or 1)
        rms = audioop.rms(raw, width) / 32768.0 if raw else 0.0
        peak = audioop.max(raw, width) / 32768.0 if raw else 0.0
        # how much of the clip is above a rough speech floor
        chunk = int(rate * 0.02) * width
        loud = sum(1 for i in range(0, max(len(raw) - chunk, 0), chunk)
                   if audioop.rms(raw[i:i + chunk], width) / 32768.0 > 0.02)
        total = max(len(raw) // chunk, 1)
        voiced = loud / total
        return {"ok": True, "seconds": num(secs, 0.0, 2), "rms": num(rms, 0.0, 4),
                "peak": num(peak, 0.0, 3), "voiced": num(voiced, 0.0, 2)}
    except Exception as e:
        return {"ok": True, "seconds": 0, "rms": 0, "peak": 0, "voiced": 0,
                "note": str(e)}


async def _listen(audio, model, level, situation, history, asr_repo):
    t0 = time.time()
    tid = uuid.uuid4().hex[:12]
    data = await audio.read()
    ext = ".mp4" if (audio.filename or "").endswith(".mp4") else ".webm"
    (WORK / f"me_{tid}{ext}").write_bytes(data)

    if len(data) < 800:
        return {"empty": True, "turn_id": tid,
                "why": f"recording was only {len(data)} bytes"}

    try:
        import mlx_whisper
    except ImportError:
        return {"empty": True, "why": "speech recogniser not installed"}

    # Checked before anything else is done with the recording. Downloading a
    # 3GB model here would freeze the turn for a quarter of an hour with a
    # progress bar in a terminal window nobody is looking at.
    if not asr_cached(asr_repo):
        return {"empty": True, "turn_id": tid,
                "why": (f"{asr_repo.split('/')[-1]} has not been downloaded yet. "
                        "Run ./setup.sh again, or choose a recogniser marked as "
                        "downloaded on the start screen."),
                "no_model": True}

    convo = json.loads(history) if history else []
    src = WORK / f"me_{tid}{ext}"
    wav = WORK / f"me_{tid}.wav"
    a = decode_audio(src, wav)
    if not a.get("ok"):
        return {"empty": True, "turn_id": tid, "why": a["why"], "audio": a}
    print(f"  audio: {a['seconds']}s  rms {a['rms']}  peak {a['peak']}  "
          f"voiced {a['voiced']}", flush=True)

    if a["seconds"] < 0.22:
        return {"empty": True, "turn_id": tid, "audio": a,
                "why": f"only {a['seconds']}s of audio, hold the button longer"}
    if a["rms"] < 0.004:
        return {"empty": True, "turn_id": tid, "audio": a,
                "why": "the recording is almost silent at the server"}
    if a.get("voiced", 1) < 0.12:
        return {"empty": True, "turn_id": tid, "audio": a,
                "why": "almost all of that recording is silence"}

    path = str(wav)

    def run(prompt, repo=None):
        res = mlx_whisper.transcribe(
            path, path_or_hf_repo=repo or asr_repo, language="zh",
            task="transcribe", initial_prompt=prompt,
            condition_on_previous_text=False,
            temperature=(0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
            compression_ratio_threshold=2.0, logprob_threshold=-1.0,
            no_speech_threshold=0.6)
        txt = re.sub(r"[「」『』]", "", (res.get("text") or "").strip())
        segs = res.get("segments") or []
        lp = [num(x.get("avg_logprob"), -5.0) for x in segs
              if x.get("avg_logprob") is not None]
        conf = num(math.exp(sum(lp) / len(lp))) if lp else 0.0
        nsp = num(max([num(x.get("no_speech_prob"), 0.0) for x in segs] or [0.0]))
        return txt, conf, nsp

    heard, conf, nsp = run(build_primer(convo))
    print(f"  heard: {heard[:80]}   conf {conf:.2f}  nospeech {nsp:.2f}", flush=True)

    # A prompt can send the decoder into a repetition loop or out of Chinese.
    # When the first pass comes back as rubbish, try again with no prompt
    # before giving up. One extra pass, only on failure.
    if is_noise(heard) and nsp <= 0.75:
        h2, c2, n2 = run(None)
        print(f"  retry without prompt: {h2[:80]}   conf {c2:.2f}", flush=True)
        if not is_noise(h2):
            heard, conf, nsp = h2, c2, n2
        else:
            # Both passes looped on this recogniser. Try a different one before
            # giving up: repetition is largely a property of the model, and a
            # steadier one often reads the same audio cleanly.
            if ASR_FALLBACK and ASR_FALLBACK != asr_repo \
                    and not asr_cached(ASR_FALLBACK):
                print(f"  second recogniser {ASR_FALLBACK} is not downloaded, "
                      f"skipping it. Run ./setup.sh to fetch it.", flush=True)
            elif ASR_FALLBACK and ASR_FALLBACK != asr_repo:
                try:
                    h3, c3, n3 = run(None, ASR_FALLBACK)
                    print(f"  retry on {ASR_FALLBACK}: {h3[:80]}   conf {c3:.2f}",
                          flush=True)
                    if not is_noise(h3):
                        heard, conf, nsp = h3, c3, n3
                except Exception as e:
                    print(f"  fallback recogniser unavailable: {e}", flush=True)
            if is_noise(heard):
                head = strip_loop(h2) or strip_loop(heard)
                if head:
                    print(f"  salvaged head: {head}", flush=True)
                    heard, conf, nsp = head, min(conf, CHECK_AT + 0.05), n2

    asr_ms = int((time.time() - t0) * 1000)

    if is_noise(heard) or nsp > 0.75:
        why = ("no speech detected in the audio" if nsp > 0.75
               else "the transcription looked like noise")
        # Whatever Chinese survived the wreckage, run it through the same
        # readings machinery an uncertain turn gets. On 蒙 Boss that is 蒙,
        # which is thin, and thin beats a dead end. When nothing survives there
        # are no chips and the typing box is the whole answer, which is honest.
        salvage = re.sub(r"[^\u4e00-\u9fff]", "", heard or "")
        alts = alternatives(salvage, 3) if len(salvage) >= 1 else []
        return {"empty": True, "turn_id": tid, "why": why,
                "heard": heard, "heard_pinyin": pinyin(heard) if heard else "",
                "conf": num(conf, 0.0, 2), "nospeech": num(nsp, 0.0, 2),
                "readings": [{"text": x, "pinyin": pinyin(x)} for x in alts],
                "my_audio": f"/api/audio/me_{tid}",
                "audio": a, "timings": {"asr": asr_ms}}

    raw = re.sub(r"[。，！？、\s]", "", heard)

    # Three outcomes, and most turns take the first one without a resolver call.
    #
    #   clear      the sounds point at one thing, it goes straight through
    #   ambiguous  two or three fit, you pick one, one click
    #   failed     nothing fits, you type it
    #
    # A confident turn costs one recogniser pass and nothing else. The resolver
    # is only paid for when there is something to resolve.
    pool = candidate_pool(raw, 4)
    accepted, certain, resolve_ms = raw, True, 0
    options = []

    if conf >= free_pass(raw) or len(pool) <= 1:
        # Heard clearly enough, or there is only one thing it could be. The
        # short-answer snap still applies, because two-syllable replies are
        # where the recogniser is weakest and the snap is exact.
        if raw not in SHORT_OK:
            sy = lazy_pinyin(raw)
            for cand in SHORT_OK:
                if sy and lazy_pinyin(cand) == sy and cand != raw:
                    accepted = cand
                    break
    else:
        t1 = time.time()
        pick, certain, natural = await resolve(model, pinyin(raw) or raw, pool,
                                               convo, situation)
        resolve_ms = int((time.time() - t1) * 1000)
        if not natural:
            # The only route to a dead end. What was heard is not an utterance,
            # so neither is any reading of the same syllables.
            accepted, certain = "", False
        else:
            # -1 means nothing beat what was heard, which is a reason to keep
            # what was heard. It is not a reason to throw the turn away. A
            # mediocre decoder score is one signal, and a sentence that plainly
            # answers the question just asked is a stronger one.
            accepted = pool[pick] if pick >= 0 else pool[0]
            if not certain:
                # The chosen one first, then the others, so the chips read as
                # "this, or one of these" rather than as a list of equals.
                options = [accepted] + [o for o in pool if o != accepted][:2]
        print(f"  resolved: {accepted or '(not an utterance)'}  "
              f"pick {pick}  natural {natural}  certain {certain}  "
              f"from {len(pool)} options in {resolve_ms}ms", flush=True)

    if not accepted:
        record("failed", turn_id=tid, heard=heard,
               heard_pinyin=pinyin(heard) if heard else "",
               conf=num(conf, 0.0, 2), nospeech=num(nsp, 0.0, 2),
               pool=pool, audio=a, asr_repo=asr_repo,
               timings={"asr": asr_ms, "resolve": resolve_ms})
        return {"empty": True, "turn_id": tid,
                "why": "could not work out what that was",
                "heard": heard, "heard_pinyin": pinyin(heard) if heard else "",
                "conf": num(conf, 0.0, 2), "nospeech": num(nsp, 0.0, 2),
                # No chips. The resolver has just said none of these is a
                # thing anyone would say, and offering them anyway contradicts
                # the only judgement in the system qualified to make that call.
                # Three lines of syllable soup under "did you mean" is worse
                # than an empty box, because reading them costs something and
                # none of them is the answer.
                "readings": [],
                "considered": [pinyin(x) for x in pool[:4]],
                "my_audio": f"/api/audio/me_{tid}",
                "audio": a,
                "timings": {"asr": asr_ms, "resolve": resolve_ms}}

    if not certain:
        state = "check"           # accepted, with the alternatives offered
    elif conf < CHECK_AT:
        state = "unsure"          # heard badly and nothing better was found
    elif conf < ACCEPT_AT:
        state = "check"           # heard, but not well enough to say nothing
    else:
        state = "ok"              # straight through

    # Readings are shown whenever the turn was not accepted outright. Hiding
    # them on a not-caught turn was a mistake: 我到了 arrived as 我到楼, one
    # syllable out, and the only thing that could have rescued it was the one
    # thing being withheld. The screen labels them as guesses, which is the
    # honest answer to their looking authoritative.
    # The chips the resolver asked for, or the dictionary's readings when no
    # resolver ran. Never on a turn that went straight through.
    alts = options or (alternatives(accepted, 3)
                       if state in ("check", "unsure") else [])

    record("heard", turn_id=tid, raw_asr=raw, raw_pinyin=pinyin(raw),
           accepted=accepted, accepted_pinyin=pinyin(accepted), state=state,
           conf=num(conf, 0.0, 2), nospeech=num(nsp, 0.0, 2), pool=pool,
           chips=alts, audio=a, asr_repo=asr_repo,
           timings={"asr": asr_ms, "resolve": resolve_ms})

    return {
        "turn_id": tid,
        "raw_asr": raw,
        "raw_pinyin": pinyin(raw),
        "text": accepted,
        "pinyin": pinyin(accepted),
        "snapped": accepted != raw,
        "english": "",            # fetched separately so recognition is not held up
        "state": state,
        "conf": num(conf, 0.0, 2),
        "readings": [{"text": a, "pinyin": pinyin(a)} for a in alts
                     if a != accepted][:3],
        "my_audio": f"/api/audio/me_{tid}",
        "audio": a,
        "timings": {"asr": asr_ms, "resolve": resolve_ms},
    }


# ------------------------------------------------------------------ typing
@app.post("/api/rewrite")
async def rewrite(typed: str = Form(""), model: str = Form(""),
                  level: str = Form("hsk2"), situation: str = Form(""),
                  history: str = Form("[]")):
    """Typed pinyin or characters into a turn.\n\n    The syllables are ground truth: they were typed. A model spells them out\n    using the conversation, its answer is read back into pinyin and rejected\n    unless it is exactly those syllables, and the dictionary answers when it\n    cannot. Nothing here can produce a sentence that was not typed."""
    typed = (typed or "").strip()
    if not typed:
        return {"error": "nothing typed"}

    unread = []
    spelled = False
    if CJK.search(typed) and not re.search(r"[A-Za-z]", typed):
        text = typed
    else:
        syls, unread = read_typed(typed)
        text = ""
        if syls:
            convo = json.loads(history) if history else []
            # The model first, checked against the syllables. The dictionary
            # behind it, unchanged, for when the model is unreachable or writes
            # something that does not spell out.
            got = await spell(model, typed, syls, convo, situation)
            spelled = bool(got)
            if not got:
                got = best_reading(syls)
            if got:
                tail = ""
                for ch in reversed(typed.strip()):
                    if ch in _END_PUNCT:
                        tail = _END_PUNCT[ch]
                        break
                    if ch.isalnum():
                        break
                text = got + tail
    if not text:
        # Say which word, because "could not read that" on a whole line gives
        # you nothing to act on.
        if unread:
            which = ", ".join(unread[:3])
            return {"error": f"not pinyin: {which}", "unread": unread}
        return {"error": "could not read that, try characters"}

    try:
        en = await gloss(model, text)
    except Exception:
        en = ""
    how = "spelled" if spelled else "dictionary"
    if unread:
        print(f"  typed: {typed}  ->  {text}  [{how}]  "
              f"(skipped: {', '.join(unread)})", flush=True)
    else:
        print(f"  typed: {typed}  ->  {text}  [{how}]", flush=True)
    # Offered as chips whether or not the line read cleanly. A typo lands on a
    # real but wrong word rather than on nothing: xinzai shi dian became
    # 新在是点, which is what the dictionary does with a missing a, and there
    # was no way from there to 现在十点.
    record("typed", typed=typed, text=text, pinyin=pinyin(text),
           unread=unread, spelled=spelled)
    return {"text": text, "pinyin": pinyin(text), "english": en,
            "unread": unread,
            "readings": [{"text": a, "pinyin": pinyin(a)}
                         for a in alternatives(text, 3)],
            "alternatives": [{"text": a, "pinyin": pinyin(a)}
                             for a in alternatives(text, 2)]}


@app.post("/api/gloss")
async def gloss_one(text: str = Form(...), model: str = Form("")):
    """An English line is part of what a turn is. When it cannot be produced,
    say so on screen rather than leaving a blank where meaning should be."""
    try:
        en = await gloss(model, text)
    except Exception:
        en = ""
    return {"english": en or "translation unavailable", "ok": bool(en)}


@app.post("/api/selftest")
async def selftest(model: str = Form(""), level: str = Form("hsk2")):
    """Runs the whole pipeline with a fixed sentence, no microphone needed.
    Every stage reports separately, so a failure points at one component
    instead of at the whole app."""
    steps = []

    def step(name, ok, detail="", ms=None):
        steps.append({"name": name, "ok": bool(ok), "detail": str(detail)[:300],
                      "ms": ms})
        return ok

    t = time.time()
    try:
        n = len(lexicon())
        step("dictionary", n > 1000, f"{n} entries", int((time.time() - t) * 1000))
    except Exception as e:
        step("dictionary", False, e)

    t = time.time()
    try:
        got = typed_to_hanzi("wo zai jia")
        step("typing works", got == "我在家", f"wo zai jia -> {got}",
             int((time.time() - t) * 1000))
    except Exception as e:
        step("typing works", False, e)

    t = time.time()
    try:
        py = pinyin("我在家。")
        step("pinyin works", py.startswith("Wǒ"), f"我在家。 -> {py}",
             int((time.time() - t) * 1000))
    except Exception as e:
        step("pinyin works", False, e)

    if not model:
        step("model reachable", False, "no model chosen")
        return {"ok": False, "steps": steps}

    t = time.time()
    try:
        raw = await ollama(model, [{"role": "user", "content": "Reply with the single word OK."}],
                           temp=0.1, predict=20)
        step("model reachable", bool(raw), f"{model} said: {raw[:60]}",
             int((time.time() - t) * 1000))
    except Exception as e:
        step("model reachable", False, e, int((time.time() - t) * 1000))
        return {"ok": False, "steps": steps}

    lvl = level_by_id(level)
    t = time.time()
    opening = await _open("A colleague asking about my weekend", level, model)
    step("opening line", bool(opening.get("pinyin")),
         opening.get("error") or f"{opening.get('pinyin')}  /  {opening.get('english')}",
         int((time.time() - t) * 1000))

    t = time.time()
    hist = [{"role": "them", "text": opening.get("text", "你好")}]
    rep = await _reply("我在家。", model, level, "A colleague asking about my weekend",
                       json.dumps(hist))
    step("reply to a turn", bool(rep.get("pinyin")),
         rep.get("error") or f"{rep.get('pinyin')}  /  {rep.get('english')}",
         int((time.time() - t) * 1000))

    t = time.time()
    cl = await _clarify(model, level, "A colleague asking about my weekend",
                        json.dumps(hist))
    step("clarification turn", bool(cl.get("pinyin")),
         cl.get("error") or cl.get("pinyin"), int((time.time() - t) * 1000))

    t = time.time()
    try:
        en = await gloss(model, "我在家。")
        step("english gloss", bool(en), en or "empty, not fatal",
             int((time.time() - t) * 1000))
    except Exception as e:
        step("english gloss", False, e)

    t = time.time()
    url = synth("你好")
    step("speech output", bool(url), url or "no audio produced (voice missing?)",
         int((time.time() - t) * 1000))

    try:
        import importlib.util
        step("recogniser installed",
             importlib.util.find_spec("mlx_whisper") is not None, WHISPER_REPO)
    except Exception as e:
        step("recogniser installed", False, e)

    fatal = {"model reachable", "opening line", "reply to a turn"}
    return {"ok": all(s["ok"] for s in steps if s["name"] in fatal), "steps": steps}


# The cases a model has to handle, taken from sessions that went wrong. Kept
# here rather than in a script under tests/, because a script under tests/ is
# invisible and the learner reasonably asked what benchmark.
COMPARE_CASES = [
    {"name": "answered no",
     "situation": "A driver taking me to the airport, and I'm running late",
     "history": [{"role": "them", "text": "你以前坐过这里吗"}],
     "said": "不，我没有",
     "watch": "a reply assuming they have flown from here is wrong"},
    {"name": "asked three times",
     "situation": "A driver taking me to the airport, and I'm running late",
     "history": [{"role": "them", "text": "你第一次来这里吗？新机场很不错。"},
                 {"role": "you", "text": "是的"},
                 {"role": "them", "text": "你以前坐过这个航班吗？"}],
     "said": "没有",
     "watch": "asking about flights again is the loop"},
    {"name": "medium spicy",
     "situation": "A waiter at a noodle place who doesn't think I can handle spicy",
     "history": [{"role": "them", "text": "好的，要加辣吗？"}],
     "said": "中辣",
     "watch": "he does not believe you can handle spice, and you hedged"},
    {"name": "praise before the food",
     "situation": "A waiter at a noodle place who doesn't think I can handle spicy",
     "history": [{"role": "them", "text": "稍等，马上就好。"}],
     "said": "你们的面条很好吃",
     "watch": "the food has not arrived yet"},
    {"name": "slow down while late",
     "situation": "A driver taking me to the airport, and I'm running late",
     "history": [{"role": "them", "text": "不客气，我们快到了。"}],
     "said": "慢一点儿",
     "watch": "you were the one in a hurry"},
    {"name": "three bottles of water",
     "situation": "A waiter at a noodle place who doesn't think I can handle spicy",
     "history": [{"role": "them", "text": "好的，还要别的吗？"}],
     "said": "我想三瓶水一杯茶",
     "watch": "that is a lot for one person"},
]


def turn_faults(text: str, theirs: list, said: str, cap: int) -> list:
    """What is structurally wrong with a reply. No judgement about meaning."""
    out = []
    if not text:
        return ["no reply"]
    if repeats_itself(text, theirs):
        out.append("repeats")
    if echoes_learner(text, said):
        out.append("echoes")
    if len(questions_in(text)) > 1:
        out.append("two questions")
    if len(re.findall(r"[\u4e00-\u9fff]", text)) > cap * 1.8:
        out.append("too long")
    return out


@app.post("/api/compare")
async def compare(models: str = Form(""), level: str = Form("hsk2"),
                  reply_len: int = Form(0)):
    """Every model, over the same turns, scored on properties of text against
    text. A model that scores badly here is not worth arguing about."""
    names = [m.strip() for m in (models or "").split(",") if m.strip()]
    if not names:
        return {"error": "no models given"}
    lvl = level_by_id(level, reply_len)
    cap = lvl["max_chars"]
    rows = []
    for name in names:
        turns, faults, asked, times = [], 0, 0, []
        for case in COMPARE_CASES:
            try:
                t0 = time.time()
                rep = await _reply(case["said"], name, level, case["situation"],
                                   json.dumps(case["history"], ensure_ascii=False),
                                   "", "", reply_len)
                ms = int((time.time() - t0) * 1000)
            except Exception as e:
                turns.append({"case": case["name"], "error": f"{type(e).__name__}: {e}"})
                faults += 1
                continue
            theirs = [m["text"] for m in case["history"] if m["role"] == "them"]
            f = turn_faults(rep.get("text", ""), theirs, case["said"], cap)
            if f:
                faults += 1
            if questions_in(rep.get("text", "")):
                asked += 1
            times.append(ms)
            turns.append({"case": case["name"], "watch": case["watch"],
                          "said": pinyin(case["said"]),
                          "pinyin": rep.get("pinyin", ""),
                          "english": rep.get("english", ""),
                          "reading": rep.get("reading", ""),
                          "faults": f, "ms": ms})
        n = len(COMPARE_CASES)
        rows.append({"model": name, "clean": n - faults, "of": n,
                     "asked": asked, "median_ms":
                     sorted(times)[len(times) // 2] if times else 0,
                     "turns": turns})
    rows.sort(key=lambda r: (-r["clean"], r["median_ms"]))
    return {"rows": rows, "cases": len(COMPARE_CASES)}


@app.post("/api/warm")
async def warm(model: str = Form(""), asr: str = Form("")):
    """Pay the cold start before the conversation, not during the first turn.

    A downloaded model is not a ready model. Loading MLX, building the
    dictionary, compiling the first inference, waking the language model and
    starting the voice all happen once and all of them used to happen while the
    learner sat holding the space bar wondering if it was broken.

    Every step reports separately and none of them can stop you starting. The
    Start button is gated on files existing on disk, which cannot be wrong in
    the way a probe can. An earlier version locked the learner out of his own
    app on the strength of a check that was mistaken."""
    steps = []

    def step(name, ok, detail="", ms=None):
        steps.append({"name": name, "ok": bool(ok), "detail": str(detail)[:200],
                      "ms": ms})

    t = time.time()
    try:
        n = len(lexicon())
        step("dictionary", n > 1000, f"{n} entries", int((time.time() - t) * 1000))
    except Exception as e:
        step("dictionary", False, e, int((time.time() - t) * 1000))

    repo = asr or WHISPER_REPO
    t = time.time()
    if not asr_cached(repo):
        step("recogniser loaded", False, f"{repo} is not downloaded")
    else:
        try:
            import mlx_whisper
            # A fifth of a second of silence. Enough to make MLX build the
            # graph and load the weights, not enough to be worth waiting for.
            quiet = WORK / "warm.wav"
            subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                            "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono",
                            "-t", "0.2", str(quiet)],
                           check=True, capture_output=True, timeout=20)
            mlx_whisper.transcribe(str(quiet), path_or_hf_repo=repo,
                                   language="zh", condition_on_previous_text=False)
            step("recogniser loaded", True, repo.split("/")[-1],
                 int((time.time() - t) * 1000))
        except Exception as e:
            step("recogniser loaded", False, f"{type(e).__name__}: {e}",
                 int((time.time() - t) * 1000))

    t = time.time()
    try:
        # keep_alive is already 30m on every call, so one token now means the
        # weights are resident for the whole session.
        await ollama(model, [{"role": "user", "content": "hi"}],
                     temp=0.0, predict=1)
        step("conversation model awake", True, model, int((time.time() - t) * 1000))
    except Exception as e:
        step("conversation model awake", False, f"{type(e).__name__}: {e}",
             int((time.time() - t) * 1000))

    t = time.time()
    url = synth("好")
    step("voice ready", bool(url), "" if url else f"{TTS_VOICE} produced nothing",
         int((time.time() - t) * 1000))

    return {"ok": all(x["ok"] for x in steps), "steps": steps,
            "total_ms": sum(x["ms"] or 0 for x in steps)}


@app.get("/api/ready")
def ready():
    """What must exist on disk before a session can start. File checks only.
    Nothing here reaches the network and nothing here is a judgement call."""
    missing = []
    if not asr_cached(WHISPER_REPO):
        missing.append(f"recogniser {WHISPER_REPO.split('/')[-1]}: run ./setup.sh")
    if not asr_cached(ASR_FALLBACK):
        missing.append(f"second recogniser {ASR_FALLBACK.split('/')[-1]}: run ./setup.sh")
    try:
        if len(lexicon()) < 1000:
            missing.append("pinyin dictionary is empty: pip install jieba")
    except Exception as e:
        missing.append(f"pinyin dictionary failed to build: {e}")
    return {"ready": not missing, "missing": missing}


@app.post("/api/wipe")
def wipe():
    """Deletes every recording of your voice. Synthesised speech is cached
    separately under say_* and is not a recording of you."""
    n, left = 0, 0
    for p in list(WORK.glob("me_*")):
        try:
            p.unlink()
            n += 1
        except OSError:
            left += 1
    return {"deleted": n, "remaining": left,
            "all_gone": left == 0 and not list(WORK.glob("me_*"))}


@app.middleware("http")
async def always_json(request, call_next):
    """Any unhandled failure becomes a JSON error the page can read and show.
    A raw traceback or an HTML error page reaches the browser as an
    unexplained parse error, which is worse than useless."""
    try:
        return await call_next(request)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return JSONResponse(
            {"error": f"{type(e).__name__}: {e}", "where": str(request.url.path)},
            status_code=500)


@app.on_event("startup")
async def warm():
    try:
        print(f"  Speaking Rig {BUILD}", flush=True)
        print(f"  dictionary: {len(lexicon())} entries", flush=True)
    except Exception as e:
        print(f"  dictionary unavailable: {e}", flush=True)


app.mount("/", StaticFiles(directory=ROOT / "static", html=True), name="static")
