#!/bin/bash
# Speaking Rig, one-time setup. Safe to run again if something failed.

cd "$(dirname "$0")" || exit 1
set -u

G=$'\033[32m'; Y=$'\033[33m'; R=$'\033[31m'; B=$'\033[1m'; N=$'\033[0m'
ok(){ echo "${G}  done${N}  $1"; }
warn(){ echo "${Y}  note${N}  $1"; }
die(){ echo "${R}  stop${N}  $1"; echo; exit 1; }
step(){ echo; echo "${B}$1${N}"; }

echo
echo "${B}Speaking Rig setup${N}"
echo "Most of this is downloading. Leave it running."

# ---------------------------------------------------------------- 1. macOS
step "1 of 6  Checking the machine"
[ "$(uname)" = "Darwin" ] || die "This is built for macOS."
if [ "$(uname -m)" != "arm64" ]; then
  warn "Intel Mac detected. It will run, but slowly."
else
  ok "Apple Silicon"
fi

# ---------------------------------------------------------------- 2. brew
step "2 of 6  Homebrew and ffmpeg"
if ! command -v brew >/dev/null 2>&1; then
  echo "  Homebrew is missing. Install it first by pasting this line, then run me again:"
  echo
  echo '  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  echo
  die "Homebrew required."
fi
ok "Homebrew found"
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "  Installing ffmpeg, which decodes and cleans up your recordings..."
  brew install ffmpeg || die "ffmpeg install failed."
fi
ok "ffmpeg ready"

# ---------------------------------------------------------------- 3. python
step "3 of 6  Python packages"
command -v python3 >/dev/null 2>&1 || die "python3 not found. Run: brew install python"
if [ ! -d .venv ]; then python3 -m venv .venv || die "Could not create the environment."; fi
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --quiet --upgrade pip
echo "  Installing Python packages. The speech one is large."
pip install --quiet fastapi "uvicorn[standard]" python-multipart httpx pypinyin jieba mlx-whisper \
  || die "Package install failed. Scroll up for the reason."
ok "Python side ready"

# ---------------------------------------------------------------- 4. ollama
step "4 of 6  Ollama and a model"
if ! command -v ollama >/dev/null 2>&1 && [ ! -d "/Applications/Ollama.app" ]; then
  warn "Ollama not found. Download it from ollama.com, then run me again."
else
  ok "Ollama installed"
  open -a Ollama 2>/dev/null || true
  sleep 3
  if curl -s --max-time 5 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    COUNT=$(curl -s http://127.0.0.1:11434/api/tags | grep -o '"name"' | wc -l | tr -d ' ')
    if [ "$COUNT" -eq 0 ]; then
      echo "  No models yet. Pulling one..."
      ollama pull qwen3:8b || warn "Pull failed. Try: ollama pull qwen3:4b"
    else
      ok "$COUNT model(s) already installed"
    fi
  else
    warn "Ollama is installed but not answering. Open the Ollama app manually."
  fi
fi

# ---------------------------------------------------------------- 5. voice
step "5 of 6  The Chinese voice"
if say -v '?' 2>/dev/null | grep -q "Tingting"; then
  ok "Tingting is installed"
else
  warn "Tingting is missing. Install it now:"
  echo "         System Settings › Accessibility › Spoken Content"
  echo "         › System Voice › Manage Voices › Chinese (China) › Tingting"
  echo "       The app runs without it, you just won't hear anything."
fi

# ---------------------------------------------------------------- 6. speech model
step "6 of 6  Downloading the speech recognisers"
echo "  Two models, about 4.5GB together. This is the long step and it is"
echo "  worth waiting out: nothing downloads once you are in a conversation."
echo "  On a slow line this can take twenty minutes. Leave it running."
python - <<'PYFETCH'
import sys
from huggingface_hub import snapshot_download

# Both are fetched here, on purpose. The second one is the retry recogniser:
# when a turn comes back as repeated nonsense the server tries it on a steadier
# model. Leaving it to download on first use meant one bad turn stalled a live
# conversation for seven minutes with nothing on screen explaining why.
for repo in ("mlx-community/whisper-large-v2-mlx",
             "mlx-community/whisper-medium-mlx"):
    print("  fetching " + repo, flush=True)
    try:
        snapshot_download(repo)
    except Exception as e:
        print("  failed: %s: %s" % (type(e).__name__, e), file=sys.stderr)
        raise SystemExit(1)
print("  both recognisers are on disk")
PYFETCH
if [ $? -ne 0 ]; then
  die "Model download failed. Check the connection, then run ./setup.sh again. It picks up where it left off."
fi
ok "Speech recognisers ready"

chmod +x start.sh 2>/dev/null || true

echo
echo "${G}${B}Setup finished.${N}"
echo "Start it any time by double-clicking ${B}start.sh${N}, or running ./start.sh here."
echo
