#!/usr/bin/env python3
"""
Speaking Rig regression suite.

Run this before shipping any change:

    cd ~/speaking-rig && source .venv/bin/activate && python tests/regression.py

Every check here exists because something broke once. The comment on each one
says what. Nothing needs Ollama or a microphone: the model and the recogniser
are both faked, so this runs anywhere in a few seconds.

If you are an assistant picking this project up: run this first, run it again
after every change, and do not ship anything that reduces the pass count. Most
of the pain in this project came from fixing one thing and quietly breaking
another.
"""

import json
import math
import os
import pathlib
import re
import sys
import types

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("OLLAMA_HOST", "http://127.0.0.1:1")  # never reachable

# ---------------------------------------------------------------- fakes
ASR = {"text": "对的", "logprob": -0.2, "nospeech": 0.01, "mode": "normal"}


def fake_transcribe(path, **kw):
    prompt = kw.get("initial_prompt")
    repo = kw.get("path_or_hf_repo", "")
    mode = ASR["mode"]
    if mode == "loop_when_primed":
        text = ("我去公司" + "ward" * 80) if prompt else "我去公司。"
    elif mode == "loop_always":
        text = "我去公司" + "ward" * 80
    elif mode == "loop_unless_fallback":
        text = "我在家。" if "medium" in repo else "我去公司" + "ward" * 80
    elif mode == "hopeless":
        text = "您" * 200
    elif mode == "gewei":
        text = "各位" * 60
    elif mode == "nan":
        return {"text": "对的", "segments": [
            {"avg_logprob": float("-inf"), "no_speech_prob": float("nan")}]}
    else:
        text = ASR["text"]
    return {"text": text, "segments": [
        {"avg_logprob": ASR["logprob"], "no_speech_prob": ASR["nospeech"]}]}


def wav_bytes(seconds=1.6, amp=0.25, rate=16000):
    """A real WAV, because ffmpeg is asked to decode this for real and will
    rightly refuse a buffer of zeroes."""
    import io
    import struct
    import wave as _w
    buf = io.BytesIO()
    with _w.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        frames = b"".join(
            struct.pack("<h", int(amp * 32767 * math.sin(2 * math.pi * 220 * i / rate)
                                  * (1 + 0.3 * math.sin(2 * math.pi * 3 * i / rate))))
            for i in range(int(rate * seconds)))
        w.writeframes(frames)
    return buf.getvalue()


GOOD_AUDIO = wav_bytes()
TINY_AUDIO = wav_bytes(seconds=0.05)

_fake = types.ModuleType("mlx_whisper")
_fake.transcribe = fake_transcribe
sys.modules["mlx_whisper"] = _fake

import server  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


RESOLVER = {"pick": 0, "certain": True, "natural": True}


async def fake_ollama(model, messages, schema=None, temp=0.7, predict=200):
    sysmsg = messages[0]["content"]
    if "You cannot write a sentence" in sysmsg:
        return json.dumps(RESOLVER)
    if "Translate the Chinese" in sysmsg:
        return json.dumps({"english": "I am at home."})
    if "did not catch what they said" in messages[-1]["content"]:
        return json.dumps({"text": "什么？没听清。", "english": "Sorry?"},
                          ensure_ascii=False)
    return json.dumps({"text": "好的。", "english": "OK."}, ensure_ascii=False)


server.ollama = fake_ollama

# The recogniser is faked here, so nothing is ever downloaded and the on-disk
# check has nothing real to look at. Stubbed for the same reason ollama and
# mlx_whisper are: the suite tests the rig, not the network. The check itself
# is tested separately, below.
_REAL_ASR_CACHED = server.asr_cached
server.asr_cached = lambda repo: True

PASS = FAIL = 0
FAILURES = []


def ck(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        FAILURES.append(f"{name}   {detail}")


def section(title):
    print(f"\n{title}")


# ---------------------------------------------------------------- files
HTML = (ROOT / "static" / "index.html").read_text()
JS = HTML.split("<script>")[1].split("</script>")[0]
SRV = (ROOT / "server.py").read_text()
SH = (ROOT / "start.sh").read_text()
SETUP = (ROOT / "setup.sh").read_text()

section("packaging and contracts")
ck("page and server builds agree",
   re.search(r"CLIENT_BUILD='([^']+)'", HTML).group(1) == server.BUILD,
   "a stale server with a fresh page wasted a whole evening")
ck("no Chinese characters anywhere in the page",
   not re.search(r"[\u4e00-\u9fff]", JS),
   "the interface is pinyin and English only")
ck("no raw confidence number shown to the learner", "confidence" not in JS,
   "0.47 reads as 47 percent and is not a probability")
ck("every response is read as text before parsing", ").json()" not in JS,
   "a NaN in the body surfaced as an unexplained SyntaxError")
ck("launcher uses its own port", "PORT=8765" in SH)
ck("launcher never blind-kills a port", "kill -9" not in SH and "lsof -ti" not in SH,
   "killing whatever holds a port is somebody else's bad day")
ck("launcher tracks its own process", ".rig.pid" in SH)
ck("launcher is not in reload mode", "--reload" not in SH)
for name in ("levels.json", "seeds.json", "hotwords.json"):
    try:
        json.loads((ROOT / name).read_text())
        ck(f"{name} parses", True)
    except Exception as e:
        ck(f"{name} parses", False, str(e))

section("recogniser choice")
ck("several recognisers offered", len(server.ASR_CHOICES) >= 3)
ck("default is large-v2", "large-v2" in server.WHISPER_REPO,
   "turbo has 4 decoder layers and loops badly on learner Mandarin")
ck("turbo is not the default", "turbo" not in server.WHISPER_REPO)
ck("a fallback recogniser is configured", bool(server.ASR_FALLBACK))
ck("setup downloads large-v2", "large-v2" in SETUP)
ck("the page offers the picker", "rig_asr" in JS and "Listening with" in HTML)

section("pinyin")
server.lexicon()
for hanzi, want in [
    ("你好，你去哪儿？", "Nǐhǎo, nǐ qù nǎr?"),      # erhua
    ("不是。我不去。", "Búshì. Wǒ bú qù."),          # 不 sandhi before 4th tone
    ("他不高兴。", "Tā bù gāoxìng."),                # and not before 1st tone
    ("我要一杯茶。", "Wǒ yào yì bēi chá."),          # 一 sandhi
    ("我在成都，我家在孟买。", "Wǒ zài Chéngdū, wǒ jiā zài Mèngmǎi."),  # proper nouns
    ("我朋友喜欢东西。", "Wǒ péngyou xǐhuan dōngxi."),  # neutral tones
    ("二十个月？不错啊。", "Èrshí gè yuè? Búcuò a."),
]:
    got = server.pinyin(hanzi)
    ck(f"pinyin {hanzi}", got == want, f"got {got!r} want {want!r}")

section("typing, which must never need a model")
for typed, want in [
    ("wo zai jia", "我在家"),
    ("chi le ma?", "吃了吗？"),
    ("wo xiang he cha", "我想喝茶"),        # 想喝 must beat the rarer 祥和
    ("duoshao qian", "多少钱"),
    ("wo qu jichang", "我去机场"),          # greedy matching gave 我区级常
    ("ni jiao shenme mingzi", "你叫什么名字"),
    ("ni xihuan la de miantiao ma?", "你喜欢辣的面条吗？"),
    ("ni xiang qu xi'an ma?", "你想去西安吗？"),   # apostrophe is a boundary
    ("ni xiang qu xian ma?", "你想去咸吗？"),      # and without it, it is not
    ("wo qu gongyuan wan", "我去公园玩"),
    ("feichang hao", "非常好"),
    ("wo qu shanghai", "我去上海"),
    ("wǒ zài jiā", "我在家"),               # tone marks optional
    ("wozaijia", "我在家"),                 # spaces optional
]:
    got = server.typed_to_hanzi(typed)
    ck(f"typed {typed!r}", got == want, f"got {got!r}")

section("possible readings")
for heard, want in [
    ("我到楼", "我到了"),          # a swallowed final particle
    ("是呀我到楼", "是呀我到了"),
    ("我去共游玩", "我去公园玩"),   # fuzzy match against your own word list
    ("我一起共园", "我一起公园"),
    ("共云", "公园"),
    ("你习惯了面条吗", "你喜欢了面条吗"),   # xihuan / xiguan is a g/h swap
]:
    got = server.alternatives(heard, 3)
    ck(f"reading for {heard}", want in got, f"got {got}")
ck("辣 stays reachable",
   any("辣" in a for a in server.alternatives("你习惯拉明天吗", 3)))
for clean in ["吃了吗", "好的"]:
    ck(f"clean turn {clean} offers nothing", server.alternatives(clean, 3) == [],
       "chips on a correct turn are noise pretending to be help")

section("noise and loops")
for text, want in [
    ("你自己啊你自己啊你", True),        # phrase repeated
    ("好的好的好的", True),
    ("是吗是吗是吗是吗", True),
    ("请不吝点赞订阅转发", True),        # youtube boilerplate
    ("各位" * 60, True),
    ("ハノ你自己留言", True),            # decoder left Chinese
    ("안녕하세요", True),
    ("呜叽叽叽叽", True),
    ("再见再见", False),               # legitimate doubling
    ("看看", False), ("慢慢走", False), ("我想想吧", False),
    ("我看印度电影。", False), ("我在家。", False), ("我很累了。", False),
]:
    ck(f"noise {text[:12]}", server.is_noise(text) == want)
ck("loop head is salvaged",
   server.strip_loop("我去公司" + "ward" * 80) == "我去公司",
   "the part before the repetition is usually the real turn")
ck("a hopeless loop yields nothing", server.strip_loop("您" * 200) == "")

section("primer")
p = server.build_primer([{"role": "them", "text": "吃了，刚吃的面条。"}])
ck("primer is short", len(p) < 160,
   "at about 28 words Whisper began echoing it back as English")
ck("primer follows the topic", "辣" in p and "面条" in p)
ck("primer always carries short answers", "对" in p and "好的" in p)

section("json safety")
ck("NaN becomes a number", server.num(float("nan")) == 0.0)
ck("infinity becomes a number", server.num(float("inf")) == 0.0)
ck("junk becomes a number", server.num("x") == 0.0 and server.num(None) == 0.0)
dirty = {"conf": float("nan"), "a": {"b": float("-inf")}, "l": [1.0, float("inf")]}
ck("a whole response can be scrubbed",
   "NaN" not in json.dumps(server.clean_json(dirty))
   and "Infinity" not in json.dumps(server.clean_json(dirty)),
   "Python writes NaN into JSON and browsers reject the entire body")

section("endpoints")
with TestClient(server.app) as c:
    def listen(audio=GOOD_AUDIO, **extra):
        data = {"model": "m", "level": "hsk2", "situation": "a colleague",
                "history": "[]"}
        data.update(extra)
        return c.post("/api/listen", data=data,
                      files={"audio": ("t.wav", audio, "audio/wav")})

    ck("index is served", c.get("/").status_code == 200)
    h = c.get("/api/health").json()
    ck("health reports the build", h["build"] == server.BUILD)
    cfg = c.get("/api/config").json()
    ck("config has levels and seeds",
       len(cfg["levels"]) == 4 and len(cfg["seeds"]) >= 20)
    ck("config offers recognisers", len(cfg.get("asr_choices", [])) >= 3)

    # confidence bands. exp(avg_logprob), from the recogniser, not from a model.
    for lp, want in [(-0.2, "ok"), (-0.8, "check"), (-1.6, "unsure")]:
        ASR["logprob"] = lp
        r = listen().json()
        ck(f"confidence band {lp} is {want}", r.get("state") == want, r)

    ASR["logprob"] = -0.2
    r = listen().json()
    ck("raw transcription is preserved separately", r.get("raw_asr") == "对的",
       "the accepted form must never overwrite what was heard")
    ck("english is deferred, not awaited", r.get("english") == "",
       "waiting on a translation delayed every turn")
    ck("audio is measured server side", (r.get("audio") or {}).get("ok") is True)
    ck("a confident turn offers no readings", r.get("readings") == [])

    ASR["logprob"] = -1.6
    ck("a not-caught turn does offer readings", "readings" in listen().json(),
       "hiding them removed the only thing that could rescue the turn")
    ASR["logprob"] = -0.2

    ASR["mode"] = "nan"
    body = listen().text
    ck("no NaN reaches the browser",
       "NaN" not in body and "Infinity" not in body and json.loads(body))

    ASR["mode"] = "loop_when_primed"
    ck("a loop is retried without the prompt", listen().json().get("text") == "我去公司")

    ASR["mode"] = "loop_always"
    ck("a persistent loop keeps its head", listen().json().get("text") == "我去公司")

    ASR["mode"] = "hopeless"
    r = listen().json()
    ck("an unusable turn is rejected with a reason",
       r.get("empty") and r.get("why"))
    ck("and reports what it heard", bool(r.get("heard")))

    ASR["mode"] = "normal"
    r = listen(audio=TINY_AUDIO).json()
    ck("a tiny recording says so", r.get("empty") and r.get("why"), r)

    r = c.post("/api/open", data={"situation": "x", "level": "hsk2",
                                  "model": "m"}).json()
    ck("opening line works", bool(r.get("pinyin")))
    r = c.post("/api/reply", data={"said": "我在家", "model": "m", "level": "hsk2",
                                   "situation": "x", "history": "[]"}).json()
    ck("reply works", bool(r.get("pinyin")))
    r = c.post("/api/clarify", data={"model": "m", "level": "hsk2",
                                     "situation": "x", "history": "[]"}).json()
    ck("clarification is tagged", r.get("kind") == "clarification",
       "so a run of bad audio does not fill history with re-asks")

    kept = [m for m in server.to_messages("P", [
        {"role": "them", "text": "A"},
        {"role": "them", "text": "B", "kind": "clarification"},
        {"role": "you", "text": "C"},
        {"role": "them", "text": "D", "kind": "clarification"}])
        if m["content"] in ("B", "D")]
    ck("only the latest clarification survives", len(kept) == 1)

    for typed, want in [("wo zai jia", "我在家"), ("吃了吗", "吃了吗")]:
        ck(f"rewrite {typed!r}",
           c.post("/api/rewrite", data={"typed": typed, "model": "m"}
                  ).json().get("text") == want)
    ck("rewrite refuses nothing gracefully",
       "error" in c.post("/api/rewrite", data={"typed": "", "model": "m"}).json())

    ck("gloss reports whether it worked",
       "ok" in c.post("/api/gloss", data={"text": "我在家。", "model": "m"}).json())
    w = c.post("/api/wipe").json()
    ck("wipe reports honestly", "all_gone" in w and "remaining" in w,
       "the screen claimed deletion without checking")

section("client behaviours")
ck("older turns are frozen", "freezeOlder" in JS,
   "editing an old turn discarded everything after it")
ck("a failed turn can be typed in place", "typeInstead" in JS,
   "otherwise a failure is a dead end")
ck("push to talk captures the pointer", "setPointerCapture" in JS,
   "drifting off the button ended the recording mid-sentence")
ck("no pointerleave handler", "addEventListener('pointerleave'" not in JS)
ck("the microphone meter does not block a turn", "peak<0.012" not in JS,
   "a suspended AudioContext reported silence and swallowed every turn")
ck("the opening line gets an english fallback",
   "if(!d.english)fillGloss(first" in JS)
ck("the failure block is height limited", "max-height:190px" in JS,
   "a looped transcription filled the screen and buried the controls")
ck("audio measurements are surfaced", "% of it speech" in JS)
ck("build mismatch is announced",
   "The server is running older code" in HTML)


# ------------------------------------------------------- downloads, never live
# A recogniser that is not on disk is a multi-minute download. One badly heard
# turn used to trigger a 1.5GB fetch of the fallback and stall a live
# conversation for seven minutes with nothing on screen. Nothing downloads
# during a session now.
section("no downloads during a session")

ck("setup fetches both recognisers",
   "whisper-large-v2-mlx" in SETUP and "whisper-medium-mlx" in SETUP,
   "the retry recogniser was left to download on first use, mid conversation")
ck("a failed download stops setup",
   "die \"Model download failed" in SETUP,
   "it used to warn and carry on, so setup passed with no model on disk")

ck("the on-disk check never reaches the network",
   "local_files_only=True" in SRV,
   "a check that downloads is the thing being prevented")
ck("an absent recogniser reads as absent",
   _REAL_ASR_CACHED("mlx-community/no-such-model-exists-xyz") is False)
ck("an empty repo name reads as absent", _REAL_ASR_CACHED("") is False)
ck("a local folder reads as present", _REAL_ASR_CACHED(str(ROOT)) is True,
   "a path on disk needs no download")

with TestClient(server.app) as c:
    server.asr_cached = lambda repo: False
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2", "situation": "x",
                     "history": "[]", "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("a missing recogniser refuses the turn", r.get("no_model") is True, r)
    ck("and says which one and what to do",
       "whisper-large-v2-mlx" in (r.get("why") or "")
       and "setup.sh" in (r.get("why") or ""), r)

    # The fallback is only reached when the first model loops twice. With the
    # fallback absent, that path must stop rather than fetch 1.5GB.
    server.asr_cached = lambda repo: repo == "mlx-community/whisper-large-v2-mlx"
    seen = []
    _orig = _fake.transcribe

    def watched(path, **kw):
        seen.append(kw.get("path_or_hf_repo", ""))
        return _orig(path, **kw)

    _fake.transcribe = watched
    ASR["mode"] = "loop_always"
    c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
           data={"model": "m", "level": "hsk2", "situation": "x",
                 "history": "[]", "asr": "mlx-community/whisper-large-v2-mlx"})
    ck("an absent second recogniser is skipped, not fetched",
       server.ASR_FALLBACK not in seen, seen)
    _fake.transcribe = _orig
    ASR["mode"] = "normal"

    server.asr_cached = lambda repo: True
    cfg = c.get("/api/config").json()
    ck("the start screen knows what is downloaded",
       all("cached" in ch for ch in cfg["asr_choices"]), cfg["asr_choices"])

ck("and the dropdown says so", "NOT DOWNLOADED" in JS,
   "picking a model that is not there used to look identical to picking one that is")


# ------------------------------------------------- words you did not say
section("words you did not say")

# 蒙 Boss scored 0.45, which cleared the line for accepting a turn with a mark
# against it, so Boss entered the conversation as a thing said out loud. Whisper
# is English first and falls back into English when it loses the thread.
ck("english inside a chinese turn is a miss", server.is_noise("蒙 Boss") is True)
ck("even when it is one stray word", server.is_noise("我到了 Boss") is True)
ck("a run of them too", server.is_noise("蛮 Boss Boss Boss") is True)
ck("clean chinese still passes", server.is_noise("机场很远。") is False,
   "the rule must not touch turns that were fine")
ck("and a short one", server.is_noise("我到了") is False)

# ------------------------------------------------- typed pinyin, word by word
section("typed pinyin")

# One unreadable word used to void the whole line, and the message named no
# word, so typing back what the screen showed failed with nothing to act on.
ck("a bad word does not void the line",
   server.read_typed("wo qu jichang ok") == (["wo", "qu", "ji", "chang"], ["ok"]))
ck("and is reported by name", server.read_typed("meng boss")[1] == ["boss"])
ck("a clean line reports nothing skipped",
   server.read_typed("jichang hen yuan")[1] == [])
ck("run-together pinyin still parses whole",
   server.read_typed("xianzai")[0] == ["xian", "zai"],
   "spacing is optional and always has been")
ck("punctuation does not make a word unreadable",
   server.read_typed("chi le ma?")[1] == [])
ck("the escape hatch still works", server.typed_to_hanzi("wo zai jia") == "我在家",
   "this is the case a model failed on, and why the dictionary exists")
ck("a line with one bad word still lands",
   server.typed_to_hanzi("wo qu jichang ok") == "我去机场")

with TestClient(server.app) as c:
    r = c.post("/api/rewrite", data={"typed": "boss", "model": "m",
                                     "level": "hsk2", "situation": "x",
                                     "history": "[]"}).json()
    ck("nothing readable says which word", "boss" in (r.get("error") or ""), r)
    r = c.post("/api/rewrite", data={"typed": "wo qu jichang ok", "model": "m",
                                     "level": "hsk2", "situation": "x",
                                     "history": "[]"}).json()
    ck("a partly readable line goes through", r.get("text") == "我去机场", r)
    ck("and says what it skipped", r.get("unread") == ["ok"], r)
    ck("typed turns carry chips", "readings" in r, r)

# ------------------------------------------------- chips on a failed turn
section("chips on a failed turn")

ck("the failing case can still be rescued", "我到了" in server.alternatives("我到楼", 3),
   "one syllable out, and the readings are the only way back")
ck("and the other one", "公园" in server.alternatives("共有", 3))

with TestClient(server.app) as c:
    ASR["mode"] = "hopeless"
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2", "situation": "x",
                     "history": "[]", "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("a rejected turn carries readings", isinstance(r.get("readings"), list), r)
    ck("and your own recording", bool(r.get("my_audio")), r)
    ASR["mode"] = "normal"

ck("the failure block renders chips", "did you mean" in JS)
ck("tapping one goes down the typing path", "function usePick" in JS,
   "a second commit path beside the tested one is a second thing to keep working")
ck("the box opens by itself", "typeInstead(el,true)" in JS)
ck("without stealing the caret", "if(!quiet)input.focus()" in JS,
   "the space bar starts a recording, and saying it again is usually the way past")


# --------------------------------------------------------- the resolver
# The version of this that was pulled out of the project could write text, and
# it wrote 你好，要去机场了吗？ over 你好,去啦吗?. This one returns a number.
section("the resolver chooses, it never writes")

ck("its output has nowhere to put a sentence",
   all(v["type"] in ("integer", "boolean")
       for v in server.RESOLVE_SCHEMA["properties"].values()),
   "a string field here is the whole failure being guarded against")

POOL = ["我到楼", "我到了", "我到吗"]

async def _res(reply):
    async def fake(model, messages, schema=None, temp=0.7, predict=200):
        return reply
    real, server.ollama = server.ollama, fake
    try:
        return await server.resolve("m", "Wo dao lou", POOL, [], "a taxi")
    finally:
        server.ollama = real

import asyncio as _aio
ck("it has a field for is this real mandarin",
   "natural" in server.RESOLVE_SCHEMA["properties"],
   "the two field version could not tell 'nothing beats what was heard' apart "
   "from 'what was heard is not an utterance', and threw away 我的行李不重 twice")
ck("it can pick a candidate",
   _aio.run(_res(json.dumps({"pick": 1, "certain": True, "natural": True})))
   == (1, True, True))
ck("minus one keeps what was heard, it does not reject it",
   _aio.run(_res(json.dumps({"pick": -1, "certain": False, "natural": True})))
   == (-1, False, True),
   "a mediocre decoder score is one signal and must not be a veto")
ck("only unnatural is a rejection",
   _aio.run(_res(json.dumps({"pick": -1, "certain": False, "natural": False})))[2]
   is False)
ck("an index off the end falls back to what was heard",
   _aio.run(_res(json.dumps({"pick": 9, "certain": True, "natural": True})))
   == (-1, True, True))
ck("a written sentence is ignored entirely",
   _aio.run(_res(json.dumps({"pick": 0, "certain": True, "natural": True,
                             "text": "我要去机场了吗"})))[0] == 0,
   "extra fields must not become the utterance")
ck("a resolver that answers nonsense does not eat the turn",
   _aio.run(_res("not json at all")) == (0, False, True),
   "what the recogniser heard stands, marked uncertain")
ck("a reply with no pick in it is a broken resolver, not a rejection",
   _aio.run(_res(json.dumps({"certain": True}))) == (0, False, True))

_pool_a = server.candidate_pool("我到楼", 4)
ck("candidates are the same length as what was heard",
   all(len(server.lazy_pinyin(c)) == 3 for c in _pool_a), _pool_a)
ck("and the rescue is among them", "我到了" in _pool_a, _pool_a)
ck("the pool cannot see the conversation",
   server.candidate_pool.__code__.co_argcount == 2,
   "it takes what was heard and a count. There is no way to pass it context, "
   "which is how context is prevented from adding to the list rather than "
   "ranking it")
ck("no chinese in, no candidates out", server.candidate_pool("Boss Boss") == [],
   "there is nothing to rank, and typing is the honest answer")

# ------------------------------------------------------- the three outcomes
section("clear, ambiguous, failed")

with TestClient(server.app) as c:
    def listen(conf):
        ASR["logprob"] = conf
        return c.post("/api/listen",
                      files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
                      data={"model": "m", "level": "hsk2", "situation": "x",
                            "history": "[]",
                            "asr": "mlx-community/whisper-large-v2-mlx"}).json()

    r = listen(-0.2)
    ck("a clear turn goes straight through", r.get("state") == "ok", r)
    ck("and pays for no resolver at all", (r.get("timings") or {}).get("resolve") == 0,
       "the mandate is explicit: do not spend on ambiguity that is not there")
    ck("and offers no chips", r.get("readings") == [], r)

    RESOLVER.update({"pick": 0, "certain": False, "natural": True})
    r = listen(-1.2)
    ck("an unsure turn is still accepted", bool(r.get("text")), r)
    ck("and offers chips", r.get("state") == "check", r)

    RESOLVER.update({"pick": -1, "certain": False, "natural": False})
    ASR["text"] = "我到楼"          # a turn with somewhere else it could have gone
    r = listen(-1.2)
    ck("only an unnatural turn is thrown away", r.get("empty") is True, r)
    ck("and still carries what it considered", isinstance(r.get("readings"), list), r)
    ck("and your own recording", bool(r.get("my_audio")), r)
    RESOLVER.update({"pick": 0, "certain": True, "natural": True})
    ASR["text"] = "对的"
    ASR["logprob"] = -0.2

# ---------------------------------------------------- learner pinyin, typed
# Section 7 of the mandate. Valid pinyin must never fail for being romanised.
section("typed pinyin, however you write it")

for typed, want in [
        ("wo shi yindu ren", "我是印度人"),
        ("wo3 shi4 yin4du4 ren2", "我是印度人"),
        ("w\u01d2 sh\u00ec y\u00ecnd\u00f9 r\u00e9n", "我是印度人"),
        ("wo xiang qu jichang", "我想去机场"),
        ("ni qu guo beijing ma", "你去过北京吗"),
        ("wo3shi4", "我是"),
        ("ni hao", "你好"),
        ("chi le ma?", "吃了吗？"),
        ("wo zai jia", "我在家")]:
    ck(f"typed: {typed}", server.typed_to_hanzi(typed) == want,
       f"got {server.typed_to_hanzi(typed)!r}, wanted {want!r}")

# ------------------------------------------------- the other person's brief
section("a brief about conversation, not about scenes")

_lvl = server.level_by_id("hsk2")
_seed = "A driver taking me to the airport, and I'm running late"
_P = server.persona_prompt(_seed, _lvl)

ck("the four rules are in it",
   "Respond naturally to the latest thing they said" in _P
   and "answer is already evident" in _P
   and "back onto an earlier thread" in _P
   and "move the conversation" in _P)
ck("no worked example from any scene is in it",
   not any(w in _P for w in ("长城", "航站楼", "gate", "terminal", "traffic")),
   "the brief carried the Great Wall and favourite gates, which is one scene "
   "baked into every scene")
ck("a scene is one line you write",
   all(isinstance(x, str) for x in
       json.loads((ROOT / "seeds.json").read_text(encoding="utf-8"))),
   "wants, knows and moves_on were fifteen scenes of ontology written by an "
   "assistant that has never been in any of them")
ck("what has been established still travels",
   "airport is behind us" in server.persona_prompt(_seed, _lvl,
                                                   "the airport is behind us"))
ck("the brief is short again", len(_P.split()) < 200,
   f"{len(_P.split())} words, from 490")

ck("nothing decides what a place is", not hasattr(server, "invented_places"),
   "a list of thirty place names is an assistant deciding what invented means")
ck("nothing decides what a yes is", not hasattr(server, "answer_polarity"),
   "whether an answer was a yes is the model noticing, not a list of "
   "characters chosen by me")
ck("and no rule forces a question to be about 你",
   "not a question about them" not in SRV,
   "that rule is what turned the other person into an interviewer")

with TestClient(server.app) as c:
    seen_prompt = {}

    async def capture(model, messages, schema=None, temp=0.7, predict=200):
        if "You cannot write a sentence" in messages[0]["content"]:
            return json.dumps(RESOLVER)
        seen_prompt["sys"] = messages[0]["content"]
        seen_prompt["last"] = messages[-1]["content"]
        return json.dumps({"text": "\u597d\u7684\u3002", "english": "OK."},
                          ensure_ascii=False)

    real, server.ollama = server.ollama, capture
    try:
        c.post("/api/reply", data={"said": "\u6211\u662f\u5370\u5ea6\u4eba",
                                   "model": "m", "level": "hsk2",
                                   "situation": _seed,
                                   "history": json.dumps(
                                       [{"role": "them",
                                         "text": "\u4f60\u662f\u54ea\u56fd\u4eba"}],
                                       ensure_ascii=False),
                                   "state": "they are Indian"})
    finally:
        server.ollama = real
    ck("the reply is told what you said",
       "\u6211\u662f\u5370\u5ea6\u4eba" in seen_prompt.get("last", ""), seen_prompt)
    ck("and what it had just asked you",
       "\u4f60\u662f\u54ea\u56fd\u4eba" in seen_prompt.get("last", ""))
    ck("and what is already established",
       "they are Indian" in seen_prompt.get("sys", ""))
    ck("and it is told what it may do, not what shape to use",
       "whichever a person would do here" in seen_prompt.get("last", ""))
    ck("and it has already said",
       "Do not say any of them again" in seen_prompt.get("last", ""))

# --------------------------------------------------------- ready and warm
section("ready before start, never during")

with TestClient(server.app) as c:
    server.asr_cached = lambda repo: True
    r = c.get("/api/ready").json()
    ck("ready is a file check and nothing else", r.get("ready") is True, r)
    server.asr_cached = lambda repo: False
    r = c.get("/api/ready").json()
    ck("a missing model is named before you start", r.get("ready") is False
       and any("setup.sh" in m for m in r["missing"]), r)
    server.asr_cached = lambda repo: True

ck("the client warms the stack before the first turn", "/api/warm" in JS)
ck("and says so while it does", "getting ready" in JS,
   "never leave the user wondering whether anything is happening")
ck("the record travels with every reply", "fd.append('state',convoState)" in JS)
ck("and is refreshed while the reply is spoken", "refreshState()" in JS,
   "so it costs no waiting")


section("push to talk")
ck("escape throws a recording away", "function abandon" in JS,
   "finishing a sentence you already know is wrong, just to be allowed to try "
   "again, happens every session")
ck("and closes the microphone", "rec.state==='recording'){rec.onstop=()=>{}" in JS)
ck("the partner stops before the mic opens", "player.pause()" in JS,
   "otherwise the voice leaks into the recording")
ck("pointer capture survives drifting off the button", "setPointerCapture" in JS)
ck("there is no listening window after the partner finishes",
   "addEventListener('pointerleave'" not in JS and "autoListen" not in JS,
   "a learner pausing to find a word is not a learner who has finished")

ck("a turn has room for a reaction and a question",
   json.loads((ROOT / "levels.json").read_text(encoding="utf-8"))[1]["max_chars"] >= 24,
   "twenty characters carried the information and dropped the personality")


# ------------------------------------------------- what a rejection means
# Three lines of syllable soup under "did you mean" is worse than an empty box.
# The resolver had already said none of these was a thing anyone would say, and
# they were offered anyway: Yao mian xiao qian zai nali, twice more.
section("a rejection means no chips")

with TestClient(server.app) as c:
    ASR["text"] = "我到楼"
    ASR["logprob"] = -1.2
    RESOLVER.update({"pick": -1, "certain": False, "natural": False})
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2", "situation": "x",
                     "history": "[]",
                     "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("nothing credible means nothing offered", r.get("readings") == [], r)
    ck("what it looked at is kept for diagnostics",
       isinstance(r.get("considered"), list) and r["considered"], r)
    RESOLVER.update({"pick": 0, "certain": True, "natural": True})
    ASR["text"] = "对的"
    ASR["logprob"] = -0.2

_src = SRV[SRV.index("async def resolve("):SRV.index("def candidate_pool(")]
ck("the resolver is shown what natural means, both ways",
   "我的行李不重 is " in _src and "要面笑前菜辣里 is not" in _src)
ck("and told option 0 starts ahead", "Option 0 is what was actually heard" in _src,
   "what the recogniser produced does not need permission to survive")
ck("and that answering the question is strong evidence",
   "even when the recogniser was unsure of itself" in _src,
   "0.50 on a sentence that directly answers what was just asked is not a veto")

# ------------------------------------------------- a missed turn stays put
# The exit became the restroom. Asked to re-ask its own question without the
# question in front of it, the model wrote a new one and the thread was gone.
section("a missed turn does not move the conversation")

with TestClient(server.app) as c:
    seen = {}

    async def capture(model, messages, schema=None, temp=0.7, predict=200):
        seen["last"] = messages[-1]["content"]
        return json.dumps({"text": "什么？", "english": "Sorry?"}, ensure_ascii=False)

    real, server.ollama = server.ollama, capture
    try:
        c.post("/api/clarify", data={
            "model": "m", "level": "hsk2", "situation": "a taxi",
            "history": json.dumps([{"role": "them", "text": "你知道出口在哪吗"}],
                                  ensure_ascii=False)})
    finally:
        server.ollama = real
    ck("the question it must re-ask is handed back to it",
       "你知道出口在哪吗" in seen.get("last", ""), seen)
    ck("and it is told not to move on",
       "do not move the conversation on" in seen.get("last", ""), seen)

# ------------------------------------------------- the turn in front of you
section("now outranks what is remembered")

_R = SRV[SRV.index("async def _reply("):SRV.index("STATE_SCHEMA")]
ck("memory records what was said, not what it implies",
   "Not what it suggests" in SRV,
   "travelling for work is not a thing anyone said")

ck("a stale record cannot overwrite a newer one", "stateApplied" in JS,
   "two updates run while replies are spoken and they can land out of order")
ck("and the turn travels with it", "fd.append('turn',String(at))" in JS)

# ------------------------------------------------- arguing about it later
section("every turn is on the record")

ck("failures are recorded", 'record("failed"' in SRV)
ck("so are the ones that worked", 'record("heard"' in SRV)
ck("and what was typed", 'record("typed"' in SRV)
ck("and the reply, with what it was given",
   'record("reply", said=said, their_last=mine, state=state' in SRV,
   "a bug gets fixed in the wrong layer when the layers are not in the record")
ck("a diagnostic never breaks a turn", "must never break a turn" in SRV)
ck("the session can be handed back", '"/api/session"' in SRV)


# ------------------------------------------------ two turns from a real session
# 16 August 2026, HSK 2, the taxi to the airport. Both of these are permanent.
section("the luggage turn, and the gate question")

with TestClient(server.app) as c:
    # The recogniser heard 我的行李不重 in direct answer to 你行李重不重, at 0.50
    # and again at 0.58, and the rig threw it away both times. The transcription
    # was correct. The layer above refused to believe it.
    ASR["text"] = "我的行李不重"
    ASR["logprob"] = -0.7                       # conf 0.50, the real number
    RESOLVER.update({"pick": -1, "certain": True, "natural": True})
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2",
                     "situation": "a driver taking me to the airport",
                     "history": json.dumps(
                         [{"role": "them", "text": "你行李重不重"}],
                         ensure_ascii=False),
                     "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("a correct transcription at 0.50 is used", r.get("text") == "我的行李不重", r)
    ck("and it is not sent to typing", r.get("empty") is not True, r)
    ASR["logprob"] = -0.545                     # conf 0.58, the second attempt
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2",
                     "situation": "a driver taking me to the airport",
                     "history": json.dumps(
                         [{"role": "them", "text": "你行李重不重"}],
                         ensure_ascii=False),
                     "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("the same at 0.58", r.get("text") == "我的行李不重", r)
    RESOLVER.update({"pick": 0, "certain": True, "natural": True})
    ASR["text"] = "对的"
    ASR["logprob"] = -0.2

# The gate question. "Have you flown from here before" answered 不，我没有 came
# back as "which gate do you like best". The word lists that caught it are gone,
# because deciding what counts as a yes is the model noticing rather than an
# assistant listing characters. What is left is the rule, in the brief, and this
# fixture as the thing to check when a model is being evaluated.
_GATE_CASE = {
    "situation": "A driver taking me to the airport, and I'm running late",
    "asked": "你以前坐过这里吗",
    "answered": "不，我没有",
    "must_not": "ask which gate, terminal or flight they preferred, since they "
                "have just said they have never been",
}
ck("the gate case is kept as a fixture for evaluating a model",
   _GATE_CASE["answered"] in json.dumps(_GATE_CASE, ensure_ascii=False))

# --------------------------------------------------------- erhua, and 一
# man yidianr ma is what was actually said into the microphone that produced
# the Boss recording. Typed back the way anyone would write it, it produced
# nothing at all: the syllables parsed, dianr matched no dictionary key, and
# the whole line came back as could not read that.
section("a bit slower")

for typed, want in [
        ("man yidianr ma", "慢一点儿吗"),
        ("man yidian ma", "慢一点吗"),
        ("qing man yidianr", "请慢一点儿"),
        ("yidianr", "一点儿"),
        ("zai nar", "在哪儿"),
        ("wo zai nar", "我在哪儿"),
        ("yi dian er", "一点儿")]:
    ck(f"erhua: {typed}", server.typed_to_hanzi(typed) == want,
       f"got {server.typed_to_hanzi(typed)!r}, wanted {want!r}")

ck("only er really ends in r",
   server.read_typed("nar")[0] == ["na", "er"]
   and server.read_typed("er")[0] == ["er"],
   "anything else ending in r is erhua and can be expanded with nothing at risk")

ck("一 holds its own sound", server.lexicon().get("yi", ("", 0))[0] == "一",
   "以 is only in the core set because it sits inside 可以, and it took yi by "
   "being later in the string")
ck("core collisions go to the commoner one",
   "commoner one wins" in SRV)
ck("and widening the core set is written up as a dead end",
   "半个小时 became 半个小是" in SRV,
   "every character added at that weight takes its sound from whatever held it")

# things the one-word-per-sound index still gets wrong. Not asserted as
# failures, because they are a known limit rather than a regression. Listed so
# that whoever fixes the index has the cases to hand.
for typed, want in [("wo yao yi bei cha", "我要一杯茶"),
                    ("shi kuai qian", "十块钱"),
                    ("ban ge xiaoshi", "半个小时"),
                    ("wo de xingli bu zhong", "我的行李不重")]:
    got = server.typed_to_hanzi(typed)
    if got != want:
        print(f"    known limit: {typed}  ->  {got}  (wanted {want})")


# ------------------------------------------- saying it once, asking it once
# Read as a conversation, one session went: the new terminal is nice, the new
# terminal is very big, the new airport is indeed big. And: is this your first
# time here, have you flown this flight before, have you taken other flights
# before. Three tellings and three askings in five turns.
section("saying it once")

_T1 = "你第一次来这里吗？新机场很不错。"
_T2 = "不知道也没事，前面左转就是。你以前坐过这个航班吗？"

ck("a repeated remark is caught",
   bool(server.repeats_itself("哦，那你是第一次坐吗？这里新航站楼很大。", [_T1])),
   "the new terminal, twice")
ck("a repeated question is caught",
   bool(server.repeats_itself("真的啊，新机场确实大。你以前坐过别的航班吗？",
                              [_T1, _T2])),
   "have you flown this flight, have you taken other flights")
ck("a fresh line goes through",
   server.repeats_itself("前面有点堵，你赶时间吗？", [_T1, _T2]) == "")
ck("and another", server.repeats_itself("你的行李重不重？", [_T1, _T2]) == "")
ck("a short line is never a repeat", server.repeats_itself("好的。", [_T1]) == "")
ck("function words alone are not a subject",
   "的" in server._EMPTY and "吗" in server._EMPTY and "航班" not in server._EMPTY)

with TestClient(server.app) as c:
    calls = []

    async def twice(model, messages, schema=None, temp=0.7, predict=200):
        if "You cannot write a sentence" in messages[0]["content"]:
            return json.dumps(RESOLVER)
        calls.append(messages[-1]["content"])
        # first answer repeats, second does not
        text = _T1 if len(calls) == 1 else "前面有点堵，你赶时间吗？"
        return json.dumps({"text": text, "english": "x"}, ensure_ascii=False)

    real, server.ollama = server.ollama, twice
    try:
        r = c.post("/api/reply", data={
            "said": "我不知道", "model": "m", "level": "hsk2",
            "situation": "A driver taking me to the airport, and I'm running late",
            "history": json.dumps([{"role": "them", "text": _T1}],
                                  ensure_ascii=False)}).json()
    finally:
        server.ollama = real
    ck("a repeat is regenerated once", len(calls) == 2, calls)
    ck("and the fresh one is used", r.get("text") == "前面有点堵，你赶时间吗？", r)
    ck("and the retry is on the record", r.get("retried") is True, r)
    ck("the model is shown what it has already said",
       "Do not say any of them again" in calls[0], calls[0][:200])
    ck("and told a finished question is finished",
       "that question is finished" in calls[0])

_P = server.persona_prompt(
    "A driver taking me to the airport, and I'm running late",
    server.level_by_id("hsk2"))
ck("the brief did not grow while being fixed", len(_P.split()) < 500,
   "a long list of rules is the thing it warns against")


# --------------------------------------- ask them, not about your own driving
# One session: can you make the flight, how long to the terminal, can we make
# it. Three questions to a passenger about the driving, from the driver. The
# tell is cheap and it held on every line of that transcript: a real question
# with no 你 in it is almost never about them.
section("questions are counted, not judged")

def problem_kind(line, prev=None):
    bad = server.reply_problems(line, prev or [])
    if not bad:
        return "ok"
    return "two" if "questions in one turn" in bad[0] else "them"

for line, want in [
        ("你飞出去过吗？新航站楼很大，你坐哪趟航班？", "two"),
        ("你去过北京吗？你喜欢吗？", "two"),
        ("哎呀，你说呢就是不知道呀。既然堵这么久，你还有行李要拿吗？", "ok"),
        ("前面有点堵，你赶时间吗？", "ok"),
        ("哦，印度啊。你在哪个城市住？", "ok"),
        ("真的吗？你什么时候来的？", "ok"),
        ("好的，你饿不饿？", "ok"),
        ("是吗？那你喜欢辣的吗？", "ok")]:
    got = problem_kind(line)
    ck(f"{want}: {line[:22]}", got == want, f"got {got}")

ck("an echo is not a question",
   server.questions_in("去印度啊？那肯定很热闹。") == [],
   "someone repeating what they just heard is not asking anything")
ck("a tag is not a question either",
   server.questions_in("是吗？那你喜欢辣的吗？") == ["那你喜欢辣的吗"],
   "真的吗 and 是吗 are reactions with a question mark attached")
ck("the question mark splits clauses", "(?<=[？?])" in SRV,
   "去印度啊？那肯定很热闹 stayed in one piece and the echo was never seen")

ck("and forbids the echo opener",
   "handing them their own words back" in SRV)
ck("the retry names every problem at once", '"\\n\\n".join(bad)' in SRV,
   "one retry, however many things are wrong with it")
ck("and only replaces the reply if it is better",
   "< len(bad)" in SRV,
   "a second attempt that is worse is not an improvement")
ck("the problems are on the record", "problems=bad" in SRV)


# --------------------------------------- how much was said changes what a score means
# A decoder that has lost the thread invents short things: Boss, 我估计到,
# 你告诉我. It does not invent 我住在孟买你呢 and hold it together for seven
# characters. A flat bar threw away two correct answers, at 0.50 and at 0.58,
# and sent them to a model that then called them unnatural.
section("a long utterance is not a short one")

ck("a short turn keeps the high bar", server.free_pass("好的") == server.RESOLVE_ABOVE)
ck("four characters too", server.free_pass("我估计到") == server.RESOLVE_ABOVE)
ck("five or more drops it",
   server.free_pass("我住在孟买你呢") == server.RESOLVE_ABOVE_LONG)
ck("the long bar is below the short one",
   server.RESOLVE_ABOVE_LONG < server.RESOLVE_ABOVE)

# Every turn of three real sessions, and where each should land.
_REAL = [("我的行李不重", 0.50, "pass"), ("我住在孟买你呢", 0.58, "pass"),
         ("我住在孟买你呢", 0.57, "pass"), ("要免小欠在哪里", 0.41, "resolve"),
         ("我是在印度你呢", 0.37, "resolve"), ("你谁呢阿里", 0.43, "resolve"),
         ("我估计到", 0.45, "resolve"), ("你告诉我", 0.53, "resolve"),
         ("我不会爱你", 0.06, "resolve"), ("我不是大耳", 0.42, "resolve")]
for text, conf, want in _REAL:
    got = "pass" if conf >= server.free_pass(text) else "resolve"
    ck(f"{text} at {conf}", got == want, f"got {got}")

with TestClient(server.app) as c:
    ASR["text"] = "我住在孟买你呢"
    ASR["logprob"] = -0.545                     # 0.58, the real number
    RESOLVER.update({"pick": -1, "certain": False, "natural": False})
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2",
                     "situation": "a driver taking me to the airport",
                     "history": "[]",
                     "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("seven characters at 0.58 never reaches the resolver",
       r.get("text") == "我住在孟买你呢" and (r.get("timings") or {}).get("resolve") == 0,
       "even a resolver saying unnatural does not get asked")
    RESOLVER.update({"pick": 0, "certain": True, "natural": True})
    ASR["text"] = "对的"
    ASR["logprob"] = -0.2

# ------------------------------------------------------- inventing a city
# A driver decided his passenger had arrived in Beijing that morning. The list
# of thirty place names that caught it is gone: an assistant deciding what
# counts as invented is exactly the ontology this is not supposed to contain.
# The rule is in the brief and the case is a fixture for evaluating a model.
section("what is not checked in code any more")

ck("no place list", not hasattr(server, "_PLACES"))
ck("a question word still beats an echo particle",
   server.questions_in("从哪座城市出发呀？") == ["从哪座城市出发呀"],
   "how a question is marked in Chinese is grammar, not ontology")
ck("and a quote is still not a question",
   server.questions_in("你说呢就是不知道呀。") == [])

# --------------------------------------- how much was said changes what a score means
# A decoder that has lost the thread invents short things: Boss, 我估计到,
# 你告诉我. It does not invent 我住在孟买你呢 and hold it together for seven
# characters. A flat bar threw away two correct answers, at 0.50 and at 0.58,
# and sent them to a model that then called them unnatural.
section("a long utterance is not a short one")

ck("a short turn keeps the high bar", server.free_pass("好的") == server.RESOLVE_ABOVE)
ck("four characters too", server.free_pass("我估计到") == server.RESOLVE_ABOVE)
ck("five or more drops it",
   server.free_pass("我住在孟买你呢") == server.RESOLVE_ABOVE_LONG)
ck("the long bar is below the short one",
   server.RESOLVE_ABOVE_LONG < server.RESOLVE_ABOVE)

# Every turn of three real sessions, and where each should land.
_REAL = [("我的行李不重", 0.50, "pass"), ("我住在孟买你呢", 0.58, "pass"),
         ("我住在孟买你呢", 0.57, "pass"), ("要免小欠在哪里", 0.41, "resolve"),
         ("我是在印度你呢", 0.37, "resolve"), ("你谁呢阿里", 0.43, "resolve"),
         ("我估计到", 0.45, "resolve"), ("你告诉我", 0.53, "resolve"),
         ("我不会爱你", 0.06, "resolve"), ("我不是大耳", 0.42, "resolve")]
for text, conf, want in _REAL:
    got = "pass" if conf >= server.free_pass(text) else "resolve"
    ck(f"{text} at {conf}", got == want, f"got {got}")

with TestClient(server.app) as c:
    ASR["text"] = "我住在孟买你呢"
    ASR["logprob"] = -0.545                     # 0.58, the real number
    RESOLVER.update({"pick": -1, "certain": False, "natural": False})
    r = c.post("/api/listen", files={"audio": ("a.webm", GOOD_AUDIO, "audio/webm")},
               data={"model": "m", "level": "hsk2",
                     "situation": "a driver taking me to the airport",
                     "history": "[]",
                     "asr": "mlx-community/whisper-large-v2-mlx"}).json()
    ck("seven characters at 0.58 never reaches the resolver",
       r.get("text") == "我住在孟买你呢" and (r.get("timings") or {}).get("resolve") == 0,
       "even a resolver saying unnatural does not get asked")
    RESOLVER.update({"pick": 0, "certain": True, "natural": True})
    ASR["text"] = "对的"
    ASR["logprob"] = -0.2

# ------------------------------------------------------- inventing a city
# A driver taking someone to the airport decided they had arrived in Beijing
# that morning, and asked which city they had set out from. Twice. Nothing in
# the conversation had said Beijing, and they were on their way out of it.
section("nothing has said Beijing")

ck("the driver is no longer told anything about airports",
   "航站楼" not in server.persona_prompt(
       "A driver taking me to the airport", server.level_by_id("hsk2")),
   "the scene is one line the learner wrote, and the model knows what a "
   "driver is")


# ------------------------------------------------- the template I wrote in
# Two whole sessions came back in one shape: their words echoed, then a
# question with 你 in it. 喜欢长城啊，那您去过吗？ 想起长城啊，那您去过吗？
# 请你告诉我？你有什么想分享的吗？ The brief said reaction then question and five
# builds of checks below it made that compulsory.
section("not one shape")

for opener, said, want in [
        ("喜欢长城啊，那您去过吗？", "我喜欢去长城", True),
        ("想起长城啊，那您去过吗？", "我想起长城", True),
        ("朋友告诉您的啊，那您现在去哪里呢？", "我朋友告诉我的", True),
        ("请你告诉我？你有什么想分享的吗？", "请你告诉我", True),
        ("你喜欢看长城？你最喜欢哪个部分？", "我喜欢看长城", True),
        ("长城我去过三次，人特别多。", "我喜欢去长城", False),
        ("孟买离这里很远。你来做什么呀？", "我是从孟买坐飞机来的", False),
        ("那边冬天冷得要命。", "我喜欢去长城", False),
        ("前面有点堵，你赶时间吗？", "我不知道", False)]:
    ck(f"echo: {opener[:14]}", server.echoes_learner(opener, said) is want,
       f"after {said}")

ck("a shared place name is not an echo",
   server.echoes_learner("孟买很远。", "我是从孟买坐飞机来的") is False,
   "two characters in common is a subject, not a parrot")

ck("two questions running is fine", server.asked_recently(["你好吗？"], 2) == 1)
ck("three is not",
   any("Do not ask anything this time" in b for b in
       server.reply_problems("那你去过长城吗？", ["你以前来过吗？", "你喜欢这里吗？"])),
   "most turns end in a question, not every turn")
ck("and a turn with no question is allowed through",
   server.reply_problems("长城我去过三次，人特别多。",
                         ["你以前来过吗？", "你喜欢这里吗？"]) == [])

# ------------------------------------------------- never shipping a known bad one
section("a flagged reply does not go out")

ck("the question can be taken off and the reaction kept",
   server.drop_question("喜欢长城啊，那您去过吗？") == "喜欢长城啊。")
ck("a turn that is all question has nothing to keep",
   server.drop_question("你去过吗？") == "")
ck("a turn with no question is untouched",
   server.drop_question("长城我去过三次，人特别多。") == "长城我去过三次，人特别多。")
ck("the fallback is wired in", "question dropped, reaction kept" in SRV,
   "两 sessions detected a repeat and sent it anyway because the retry was no better")
ck("and what is still wrong is on the record", "still_flagged" in SRV)

# ------------------------------------------------- the doubled turn, and steering
section("one reply per turn, and you can steer it")

ck("every turn takes a number", "let thread=0" in JS)
ck("a superseded reply is thrown away", "if(mine!==thread)return" in JS,
   "picking a chip while the first reply was in flight rendered both")
ck("and the chip cannot be clicked while one is out", "if(busy)return;" in JS)
ck("you can take it somewhere else", "take it somewhere else" in JS)
ck("the steer reaches the server", "fd.append('steer',steer)" in JS)
ck("and outranks what it was going to say",
   "THE DIRECTION FOR THIS TURN" in SRV,
   "you know what you want to practise and the rig does not")


# ------------------------------------------------- ordering chicken noodles
# A whole session was lost ordering noodles, water and tea. Every measure word
# in the language fails the one-word-per-sound index: 杯 loses to 北, 碗 to 玩,
# 份 to 分, 瓶 to 平 and 鸡 to 及, so 一杯茶 typed out came back as 一北茶 and
# ji de miantiao as 记得面条, remember the noodles.
section("which characters these syllables spell")

for typed, wrong in [("yi bei cha", "一北茶"), ("yi wan miantiao", "一玩面条"),
                     ("san ping shui", "三平水"), ("ji de miantiao", "记得面条"),
                     ("yi fen ji miantiao", "一分及面条")]:
    ck(f"the dictionary alone still gets {typed} wrong",
       server.best_reading(server.read_typed(typed)[0]) == wrong,
       "kept as the record of why the spelling layer exists")

ck("鸡 is out of reach by frequency at any beam width",
   "鸡的面条" not in [r for r, _ in
                   server.readings(server.read_typed("ji de miantiao")[0], 24)],
   "fifteenth commonest word for the sound ji. Three builds were spent trying "
   "to widen the index to it")

# The whole safety of this layer is one comparison. A model that writes a
# better sentence than the one typed does not spell out to the same syllables,
# and is thrown away.
for hanzi, syls, want in [
        ("鸡的面条", ["ji", "de", "mian", "tiao"], True),
        ("记得面条", ["ji", "de", "mian", "tiao"], True),
        ("我想吃鸡面条", ["ji", "de", "mian", "tiao"], False),
        ("一杯茶", ["yi", "bei", "cha"], True),
        ("一杯咖啡", ["yi", "bei", "cha"], False),
        ("三瓶水", ["san", "ping", "shui"], True),
        ("慢一点儿", ["man", "yi", "dianr"], True),
        ("慢一点儿", ["man", "yi", "dian", "er"], True),
        ("在哪儿", ["zai", "nar"], True),
        ("我在家", ["wo", "zai", "jia"], True),
        ("我在家里", ["wo", "zai", "jia"], False),
        ("", ["wo"], False),
        ("要不要去机场呢", ["wo", "qu", "ji", "chang"], False)]:
    ck(f"spells_out {hanzi or '(empty)'} as {' '.join(syls)}: {want}",
       server.spells_out(hanzi, syls) is want)

ck("its output has nowhere to put anything but characters",
   set(server.SPELL_SCHEMA["properties"]) == {"hanzi"})

with TestClient(server.app) as c:
    async def spells(model, messages, schema=None, temp=0.7, predict=200):
        if "You write out pinyin" in messages[0]["content"]:
            return json.dumps({"hanzi": "一杯茶"}, ensure_ascii=False)
        return json.dumps({"english": "a cup of tea"})

    real, server.ollama = server.ollama, spells
    try:
        r = c.post("/api/rewrite", data={"typed": "yi bei cha", "model": "m",
                                         "level": "hsk2", "situation": "a tea house",
                                         "history": "[]"}).json()
    finally:
        server.ollama = real
    ck("a typed cup of tea is a cup of tea", r.get("text") == "一杯茶", r)

    async def invents(model, messages, schema=None, temp=0.7, predict=200):
        if "You write out pinyin" in messages[0]["content"]:
            return json.dumps({"hanzi": "我想要一杯热茶谢谢"}, ensure_ascii=False)
        return json.dumps({"english": "x"})

    real, server.ollama = server.ollama, invents
    try:
        r = c.post("/api/rewrite", data={"typed": "yi bei cha", "model": "m",
                                         "level": "hsk2", "situation": "a tea house",
                                         "history": "[]"}).json()
    finally:
        server.ollama = real
    ck("a better sentence than the one typed is thrown away",
       r.get("text") == "一北茶", r)
    ck("and the dictionary answers instead, wrong but honest",
       "spelling rejected" in SRV)

    async def dead(model, messages, schema=None, temp=0.7, predict=200):
        if "You write out pinyin" in messages[0]["content"]:
            raise RuntimeError("ollama is not running")
        return json.dumps({"english": "x"})

    real, server.ollama = server.ollama, dead
    try:
        r = c.post("/api/rewrite", data={"typed": "wo zai jia", "model": "m",
                                         "level": "hsk2", "situation": "home",
                                         "history": "[]"}).json()
    finally:
        server.ollama = real
    ck("no model, and typing still works", r.get("text") == "我在家", r,)

ck("which way it was read is on the record", "spelled=spelled" in SRV)


# ------------------------------------------- understanding before answering
# Four turns in one session were correct and empty. Told 中辣 by a waiter who
# does not believe the learner can handle spice, he offered to add spicy chicken.
# Praised for noodles still in the kitchen, he said thank you, we always take
# care. Asked to slow down by a passenger who was running late, he said be
# careful. Nothing wrong in any of them.
section("read it, then answer it")

ck("the reply has to say what it understood first",
   list(server.TURN_SCHEMA["properties"])[0] == "reading",
   "a field filled after the sentence is written is a caption, not a reading")
ck("and it is required", "reading" in server.TURN_SCHEMA["required"])
ck("and it is english, so it can be read", "English" in
   server.TURN_SCHEMA["properties"]["reading"]["description"])

_R = SRV[SRV.index("async def _reply("):SRV.index("STATE_SCHEMA")]
ck("it is asked what is worth remarking on", "worth remarking on" in _R)
ck("and told where to look",
   "gap between what they said and what you were expecting" in _R,
   "every one of those four turns had one")
ck("and that the reading drives the reply",
   "that is\n             what your reply is about" in _R or "what your reply is about" in _R)

with TestClient(server.app) as c:
    async def reads(model, messages, schema=None, temp=0.7, predict=200):
        if "You cannot write a sentence" in messages[0]["content"]:
            return json.dumps(RESOLVER)
        return json.dumps({"reading": "they hedged on spice and I doubt them",
                           "text": "中辣？行，我看看你行不行。",
                           "english": "Medium? Right, we'll see."},
                          ensure_ascii=False)

    real, server.ollama = server.ollama, reads
    try:
        r = c.post("/api/reply", data={
            "said": "中辣", "model": "m", "level": "hsk2",
            "situation": "A waiter at a noodle place who doesn't think I can handle spicy",
            "history": json.dumps([{"role": "them", "text": "好的，要加辣吗？"}],
                                  ensure_ascii=False)}).json()
    finally:
        server.ollama = real
    ck("the reading comes back with the turn",
       "hedged on spice" in (r.get("reading") or ""), r)
    ck("and is on the record", "reading=out.get" in SRV)

ck("the screen can show it", 'data-a="reading"' in JS)
ck("folded away until asked for", "what it understood" in JS)

# ---------------------------------------------------- room to say something
section("room to notice something")

_lv = json.loads((ROOT / "levels.json").read_text(encoding="utf-8"))
ck("hsk2 has room for a reaction and an answer",
   next(x for x in _lv if x["id"] == "hsk2")["max_chars"] >= 36,
   "eight characters was a receipt: 那给您加辣的鸡。")
ck("and it is settable without editing a file", "reply_len" in SRV)
ck("clamped at both ends",
   server.level_by_id("hsk2", 5)["max_chars"] == server.REPLY_LEN_MIN
   and server.level_by_id("hsk2", 999)["max_chars"] == server.REPLY_LEN_MAX)
ck("zero means leave the level alone",
   server.level_by_id("hsk2", 0)["max_chars"]
   == next(x for x in _lv if x["id"] == "hsk2")["max_chars"])
ck("there is a control on the start screen", 'id="rlen"' in HTML)
ck("and it survives a restart", "rig_rlen" in JS)

# ------------------------------------------------------- what benchmark
section("the benchmark you can find")

ck("comparing models is in the app, not in a script",
   '"/api/compare"' in SRV,
   "a file under tests/ is invisible, and the learner asked what benchmark")
ck("there is a button for it", 'id="compare"' in HTML)
ck("the cases come from sessions that went wrong",
   len(server.COMPARE_CASES) >= 6
   and any(c["said"] == "中辣" for c in server.COMPARE_CASES)
   and any("面条很好吃" in c["said"] for c in server.COMPARE_CASES))
ck("every case says what to watch for",
   all(c.get("watch") for c in server.COMPARE_CASES))
ck("the scoring makes no claim about meaning",
   server.turn_faults("好的。", [], "中辣", 40) == []
   and "repeats" in server.turn_faults("好的，要加辣吗？", ["好的，要加辣吗？"], "中辣", 40),
   "it counts repeats, echoes, doubled questions and length. Nothing else.")
ck("and a long one is caught",
   "too long" in server.turn_faults("好" * 200, [], "中辣", 40))


# ------------------------------------------------- documentation that is true
# A public repository whose README describes a different program is worse than
# no README. These are the claims that can be checked mechanically.
section("the documentation matches the code")

README = (ROOT / "README.md").read_text(encoding="utf-8")
ARCH = (ROOT / "ARCHITECTURE.md").read_text(encoding="utf-8")

_eps = set(re.findall(r'@app\.(?:get|post)\("(/api/[^"]*)"', SRV))
_doc = set(re.findall(r'`(/api/[a-z_/{}]+)`', ARCH))
ck("every endpoint is documented", not (_eps - _doc - {"/api/session/clear"}),
   f"undocumented: {sorted(_eps - _doc - {'/api/session/clear'})}")
ck("and nothing documented has been removed", not (_doc - _eps),
   f"gone from the code: {sorted(_doc - _eps)}")

_env = set(re.findall(r'os\.environ\.get\("([A-Z_]+)"', SRV))
_tbl = set(re.findall(r'\| `([A-Z_]+)` \|', README))
ck("every setting is in the README table", not (_env - _tbl),
   f"missing: {sorted(_env - _tbl)}")
ck("and the table has no settings that do not exist", not (_tbl - _env),
   f"stale: {sorted(_tbl - _env)}")

ck("the check count in the README is not a guess",
   "421 checks" in README or "421 regression checks" in README,
   "if this fires, update the number in README.md and ARCHITECTURE.md")
ck("the section count in ARCHITECTURE is right",
   str(len(re.findall(r'section\("', (ROOT / "tests" / "regression.py")
                      .read_text(encoding="utf-8")))) in ARCH)

ck("the requirements are split the way the repository promises",
   "### System" in README and "### Human" in README)
ck("the human requirements say pinyin is not optional",
   "Reads pinyin with tone marks" in README
   and "Non-negotiable" in README)
ck("the limitations are in the README, not only in DECISIONS",
   "## Limitations" in README and "Whisper is English-first" in README)
ck("the three invariants are written down",
   "one reply per accepted turn" in README.lower()
   and "never enters the conversation" in README
   and "nothing downloads\nduring a session" in README.lower()
   or "nothing downloads" in README.lower())
ck("and so is the rule about what code may decide",
   "compares text against text" in README
   and "not one makes a claim about meaning" in README,
   "a reader should learn where the line is without opening another file")
ck("the learner half comes before the developer half",
   README.index("# Speaking Rig") < README.index("# For developers"),
   "somebody landing here is a learner until proven otherwise")
ck("and the developer half says so out loud",
   "Learners can stop at the line above" in README)
ck("the battle scars are one collapsible section",
   README.count("<details") >= 7 and "## Battle scars" in README,
   "seven evenings of findings, folded so the page is still readable")

# The cue card is the first thing a stranger uses, so every line on it has to
# work. All ten are checked here: the typed form parses, and it spells out to
# the same syllables as the characters it claims to be.
CUES = (ROOT / "CUES.md").read_text(encoding="utf-8")
ck("the cue card exists and the README points at it",
   "CUES.md" in README and len(CUES) > 1000)

_CUES = [("我要去机场", "wo yao qu jichang"),
         ("还要多久到机场", "hai yao duo jiu dao jichang"),
         ("我时间不多了", "wo shijian bu duo le"),
         ("请开慢一点儿", "qing kai man yidianr"),
         ("我没来过这里", "wo mei lai guo zheli"),
         ("我要一碗鸡蛋面", "wo yao yi wan jidan mian"),
         ("我不能吃太辣的", "wo bu neng chi tai la de"),
         ("有没有不辣的菜", "you mei you bu la de cai"),
         ("请再给我一杯茶", "qing zai gei wo yi bei cha"),
         ("一共多少钱", "yi gong duo shao qian")]
for hanzi, typed in _CUES:
    syls, unread = server.read_typed(typed)
    ck(f"cue parses: {typed}", bool(syls) and not unread, f"skipped {unread}")
    ck(f"cue spells out: {typed}", server.spells_out(hanzi, syls),
       f"{hanzi} is not {' '.join(syls)}")
    ck(f"cue is on the card: {typed}", typed in CUES and hanzi in CUES)
    ck(f"cue is long enough for the lower bar: {hanzi}",
       server.free_pass(hanzi) == server.RESOLVE_ABOVE_LONG,
       "under five characters and the recogniser has to be confident")

ck("the card says what a working reply looks like",
   CUES.count("What a working reply looks like") == 2)
ck("and how to read a failure",
   "一北茶" in CUES and "Ollama is not reachable" in CUES,
   "two of the lines exist partly to catch a missing model")
ck("and does not promise pinyin is optional",
   "cannot read pinyin with tone marks" in CUES)

ck("there is a licence", (ROOT / "LICENSE").exists())
ck("and a gitignore that keeps your voice out of a commit",
   "*.wav" in (ROOT / ".gitignore").read_text(encoding="utf-8"))
ck("no personal names are left in the repository",
   not any(w in (README + ARCH + SRV + (ROOT / "DECISIONS.md").read_text(encoding="utf-8")
                 + (ROOT / "SETUP.md").read_text(encoding="utf-8"))
           for w in ("Nianzhen", "sreeraman")),
   "it is going public")

print(f"\n{'=' * 60}")
if FAILURES:
    print(f"{PASS} passed, {FAIL} FAILED\n")
    for f in FAILURES:
        print(f"  FAILED: {f}")
    sys.exit(1)
print(f"{PASS} passed, 0 failed")
