#!/usr/bin/env python3
"""
Which model can hold the conversation without the scaffolding.

    cd ~/speaking-rig && source .venv/bin/activate
    python tests/bench_reply.py                 # every model you have
    python tests/bench_reply.py qwen3:8b qwen3:14b

Runs each model over conversation states taken from real sessions, several
times each, and scores every reply against the four rules. Nothing here judges
meaning. Every check is a property of the text against other text:

    repeats itself      a run of four characters, or a question sharing its
                        subject words, with something that person already said
    echoes the learner   opens by handing back what the learner just said
    two questions        two question clauses in one turn
    all one shape        every reply in the run ends in a question
    over length          well past the level's character budget

A model that scores zero here is not necessarily good. A model that scores
badly here is definitely not good, and that is the question worth answering
before deciding whether a rule belongs in code or in the prompt.

Add a case whenever a session goes wrong. The cases are the specification.
"""
import asyncio
import json
import os
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("OLLAMA_HOST", "http://127.0.0.1:11434")

RUNS = int(os.environ.get("RUNS", "3"))

# Conversation states from real sessions. Each one is a place where a build
# went wrong, so a model that handles all of them handles what has actually
# happened rather than what might.
CASES = [
    {"name": "answered no",
     "situation": "A driver taking me to the airport, and I'm running late",
     "history": [{"role": "them", "text": "你以前坐过这里吗"}],
     "said": "不，我没有",
     "note": "a reply assuming they have flown from here is wrong"},
    {"name": "asked and answered",
     "situation": "A driver taking me to the airport, and I'm running late",
     "history": [{"role": "them", "text": "你第一次来这里吗？新机场很不错。"},
                 {"role": "you", "text": "是的"},
                 {"role": "them", "text": "不知道也没事，前面左转就是。你以前坐过这个航班吗？"}],
     "said": "没有",
     "note": "asking about flights a third time is the loop"},
    {"name": "the order",
     "situation": "A waiter at a noodle place who doesn't think I can handle spicy",
     "history": [{"role": "them", "text": "您平时吃辣吗？"},
                 {"role": "you", "text": "我要中辣"},
                 {"role": "them", "text": "中辣啊，那我们给您准备一份。您平时还喜欢吃什么口味的面？"}],
     "said": "我要鸡面条一杯茶",
     "note": "echoing the order back is the template"},
    {"name": "they told you where they live",
     "situation": "Someone who has just found out I am from India",
     "history": [{"role": "them", "text": "你是来旅游的吗？"},
                 {"role": "you", "text": "是的"},
                 {"role": "them", "text": "你之前去过哪些地方？"}],
     "said": "我住在印度",
     "note": "asking where they are from is already answered"},
    {"name": "a bare fact",
     "situation": "A stranger on a long train who wants to know why I'm learning Chinese",
     "history": [{"role": "them", "text": "你学中文多久了？"}],
     "said": "两年",
     "note": "two characters, and the reply has to build something from it"},
    {"name": "nothing to work with",
     "situation": "A shopkeeper who will not come down on the price",
     "history": [{"role": "them", "text": "这个八十块，很便宜了。"}],
     "said": "太贵了",
     "note": "a disagreement, which a person answers rather than surveys"},
]


def models():
    import httpx
    try:
        r = httpx.get(f"{os.environ['OLLAMA_HOST']}/api/tags", timeout=8)
        return sorted(m["name"] for m in r.json().get("models", []))
    except Exception as e:
        raise SystemExit(f"\n  Ollama is not answering: {e}\n")


async def one(server, model, case, level="hsk2"):
    return await server._reply(case["said"], model, level, case["situation"],
                               json.dumps(case["history"], ensure_ascii=False))


def score(server, reply, case, cap):
    theirs = [m["text"] for m in case["history"] if m["role"] == "them"]
    text = reply.get("text", "")
    faults = []
    if not text:
        return ["no reply"], 0
    if server.repeats_itself(text, theirs):
        faults.append("repeats")
    if server.echoes_learner(text, case["said"]):
        faults.append("echoes")
    if len(server.questions_in(text)) > 1:
        faults.append("two questions")
    n = len(__import__("re").findall(r"[一-鿿]", text))
    if n > cap * 1.8:
        faults.append("too long")
    return faults, len(server.questions_in(text))


def main():
    import server
    wanted = sys.argv[1:] or models()
    have = models()
    live = [m for m in wanted if m in have]
    for m in wanted:
        if m not in have:
            print(f"  not installed, skipped: {m}")
    if not live:
        raise SystemExit("  no model to test. Try: ollama pull qwen3:14b")

    lvl = server.level_by_id("hsk2")
    cap = lvl["max_chars"]
    table = {}
    for model in live:
        print(f"\n{'=' * 66}\n  {model}\n{'=' * 66}")
        faults, qs, times = [], [], []
        for case in CASES:
            print(f"\n  {case['name']}   ({case['note']})")
            print(f"    they said: {server.pinyin(case['said'])}")
            for i in range(RUNS):
                try:
                    rep = asyncio.run(one(server, model, case))
                except Exception as e:
                    print(f"    run {i + 1}: failed {type(e).__name__}: {e}")
                    faults.append(["error"])
                    continue
                f, q = score(server, rep, case, cap)
                faults.append(f)
                qs.append(q)
                times.append((rep.get("timings") or {}).get("reply", 0))
                mark = "clean" if not f else ", ".join(f)
                print(f"    {mark:22s} {server.pinyin(rep.get('text', ''))[:52]}")
        clean = sum(1 for f in faults if not f)
        allq = sum(1 for q in qs if q >= 1)
        table[model] = {
            "clean": clean, "of": len(faults),
            "always_asks": allq == len(qs) and len(qs) > 0,
            "ask_rate": (allq / len(qs)) if qs else 0,
            "ms": int(statistics.median(times)) if times else 0,
        }

    print(f"\n{'=' * 66}\n  summary\n{'=' * 66}")
    print(f"  {'model':22s} {'clean':>8s} {'asks':>8s} {'median':>9s}")
    for m, r in sorted(table.items(), key=lambda x: -x[1]["clean"]):
        note = "  every turn is a question" if r["always_asks"] else ""
        print(f"  {m:22s} {r['clean']:4d}/{r['of']:<3d} "
              f"{r['ask_rate'] * 100:6.0f}% {r['ms']:8d}ms{note}")
    print("\n  clean means no repeat, no echo, one question at most, sane length.")
    print("  asks is how often a turn ended in a question. Every turn is an")
    print("  interview; never is a wall to talk at.\n")


if __name__ == "__main__":
    main()
