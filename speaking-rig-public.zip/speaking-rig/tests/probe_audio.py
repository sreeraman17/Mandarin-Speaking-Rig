#!/usr/bin/env python3
"""
Probe one recording, on your machine, with the models you already have.

    cd ~/speaking-rig && source .venv/bin/activate
    python tests/probe_audio.py /path/to/me_c7f2642feb73.wav

It reads the clip, prints where its energy sits, then transcribes it four ways:
as-is and high-passed, on both recognisers. Nothing is downloaded. If a model
is not on disk it is skipped and said so.

The question this answers: when a turn comes back as "Boss Boss Boss", is the
recording carrying the speech, or is the recogniser inventing?
"""
import math
import sys
import subprocess
import tempfile
import wave
from pathlib import Path

MODELS = ["mlx-community/whisper-large-v2-mlx", "mlx-community/whisper-medium-mlx"]


def load(path):
    with wave.open(str(path), "rb") as w:
        rate = w.getframerate()
        raw = w.readframes(w.getnframes())
    return raw, rate


def bands(path):
    try:
        import numpy as np
    except ImportError:
        print("  (numpy not installed, skipping the measurements)")
        return
    raw, rate = load(path)
    import numpy as np
    x = np.frombuffer(raw, dtype="<i2").astype(float) / 32768
    n = max(1 << 14, len(x))
    P = abs(np.fft.rfft(x * np.hanning(len(x)), n=n)) ** 2
    fr = np.fft.rfftfreq(n, 1 / rate)
    P = P / P.sum()
    print(f"  {len(x)/rate:.2f}s   rms {math.sqrt((x**2).mean()):.4f}   "
          f"peak {abs(x).max():.3f}")
    for a, b, note in [(0, 300, "rumble, wants to be small"),
                       (300, 1000, "vowels"),
                       (1000, 3400, "consonants"),
                       (3400, 8000, "sibilants: sh x s c ch q j")]:
        m = (fr >= a) & (fr < b)
        print(f"    {a:5d}-{b:5d} Hz   {100*P[m].sum():6.2f}%   {note}")
    top = fr[np.searchsorted(np.cumsum(P), 0.99)]
    print(f"    99% of the energy is below {top:.0f} Hz")
    if top < 4500:
        print("    NOTE: that ceiling is telephone grade. A Bluetooth headset "
              "in call mode does exactly this.")


def highpass(src):
    dst = Path(tempfile.gettempdir()) / (Path(src).stem + "_hp.wav")
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-i", str(src), "-af", "highpass=f=120:poles=2",
                    str(dst)], check=True)
    return dst


def hear(path, repo):
    import mlx_whisper
    res = mlx_whisper.transcribe(
        str(path), path_or_hf_repo=repo, language="zh", task="transcribe",
        initial_prompt=None, condition_on_previous_text=False,
        temperature=(0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
        compression_ratio_threshold=2.0, logprob_threshold=-1.0,
        no_speech_threshold=0.6)
    segs = res.get("segments") or []
    lp = [s["avg_logprob"] for s in segs if s.get("avg_logprob") is not None]
    conf = math.exp(sum(lp) / len(lp)) if lp else 0.0
    return (res.get("text") or "").strip(), conf


def on_disk(repo):
    try:
        from huggingface_hub import snapshot_download
        d = Path(snapshot_download(repo, local_files_only=True))
        return "config.json" in {f.name for f in d.iterdir()}
    except Exception:
        return False


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(1)
    src = Path(sys.argv[1])
    print(f"\n{src.name}")
    bands(src)
    hp = highpass(src)
    print("\n  high-passed at 120 Hz")
    bands(hp)
    print()
    for repo in MODELS:
        if not on_disk(repo):
            print(f"  {repo.split('/')[-1]:24s} not downloaded, skipped")
            continue
        for label, f in [("as-is", src), ("high-passed", hp)]:
            try:
                txt, conf = hear(f, repo)
            except Exception as e:
                txt, conf = f"failed: {type(e).__name__}: {e}", 0.0
            print(f"  {repo.split('/')[-1]:24s} {label:12s} "
                  f"conf {conf:.2f}   {txt[:60]}")
    print()


if __name__ == "__main__":
    main()
