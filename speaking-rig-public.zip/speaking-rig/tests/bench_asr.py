#!/usr/bin/env python3
"""
Benchmark recognisers against your own voice.

    cd ~/speaking-rig && source .venv/bin/activate
    python tests/bench_asr.py

It reads tests/fixtures/fixtures.json, runs every recogniser that is already on
disk over every recording, and prints a table. Nothing is downloaded. A model
that is not there is skipped and said so.

The question it answers is not generic Mandarin accuracy. It is: which of these
recovers what THIS learner was reasonably trying to say. That is the only
number worth tuning on, and the only way to get it is your own recordings.

Adding a fixture, whenever a turn goes wrong:

    1. the rig keeps every recording. Find it in the work folder, the failure
       block on screen names the turn id.
    2. copy it into tests/fixtures/
    3. add an entry to fixtures.json with what you were actually trying to say,
       in pinyin, and what the rig should have done with it.

Real failures beat synthetic audio and beat clean native-speaker samples. This
learner's voice is the specification.
"""
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
FIX = Path(__file__).resolve().parent / "fixtures"

MODELS = [
    "mlx-community/whisper-large-v2-mlx",
    "mlx-community/whisper-medium-mlx",
    "mlx-community/whisper-large-v3-mlx",
    "mlx-community/whisper-large-v3-turbo",
]


def on_disk(repo):
    try:
        from huggingface_hub import snapshot_download
        d = Path(snapshot_download(repo, local_files_only=True))
        return "config.json" in {f.name for f in d.iterdir()}
    except Exception:
        return False


def hear(path, repo, prompt=None):
    import mlx_whisper
    res = mlx_whisper.transcribe(
        str(path), path_or_hf_repo=repo, language="zh", task="transcribe",
        initial_prompt=prompt, condition_on_previous_text=False,
        temperature=(0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
        compression_ratio_threshold=2.0, logprob_threshold=-1.0,
        no_speech_threshold=0.6)
    segs = res.get("segments") or []
    lp = [s["avg_logprob"] for s in segs if s.get("avg_logprob") is not None]
    conf = math.exp(sum(lp) / len(lp)) if lp else 0.0
    return (res.get("text") or "").strip(), conf


def main():
    import server
    f = FIX / "fixtures.json"
    if not f.exists():
        print(f"\n  No fixtures yet. Create {f} and put recordings beside it.")
        print(__doc__)
        raise SystemExit(1)
    cases = json.loads(f.read_text(encoding="utf-8"))
    live = [m for m in MODELS if on_disk(m)]
    for m in MODELS:
        if m not in live:
            print(f"  skipped, not downloaded: {m}")
    if not live:
        raise SystemExit("  no recogniser is on disk. Run ./setup.sh")

    print()
    score = {m: 0 for m in live}
    for case in cases:
        audio = FIX / case["audio"]
        if not audio.exists():
            print(f"  missing recording: {audio}")
            continue
        want = case.get("meant_pinyin", "")
        print(f"\n  {case['audio']}")
        print(f"    you meant: {want}")
        for repo in live:
            try:
                txt, conf = hear(audio, repo)
            except Exception as e:
                print(f"    {repo.split('/')[-1]:22s} failed: {type(e).__name__}")
                continue
            got = server.pinyin(txt) if txt else ""
            pool = server.candidate_pool(
                __import__("re").sub(r"[^一-鿿]", "", txt), 4)
            rescued = any(server.pinyin(c).lower().replace(" ", "")
                          == want.lower().replace(" ", "") for c in pool)
            direct = got.lower().replace(" ", "") == want.lower().replace(" ", "")
            mark = "exact" if direct else ("in candidates" if rescued else "lost")
            if direct:
                score[repo] += 2
            elif rescued:
                score[repo] += 1
            print(f"    {repo.split('/')[-1]:22s} conf {conf:.2f}  "
                  f"{mark:14s} {got[:44]}")

    print("\n  score: 2 for heard outright, 1 for reachable from the chips\n")
    for repo, n in sorted(score.items(), key=lambda x: -x[1]):
        print(f"    {n:3d}  {repo}")
    print()


if __name__ == "__main__":
    main()
