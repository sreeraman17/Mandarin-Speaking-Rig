#!/usr/bin/env python3
"""
Turn a session into the only number that matters.

    cd ~/speaking-rig && source .venv/bin/activate
    python tests/label_session.py

Walks the turns the rig recorded and asks you two things about each one. Then
it prints the score:

    how many of these turns moved the conversation on
    without you having to fight the machine

That is the benchmark. A passing test count says the parts work. It does not
say the conversation did. After a session, spend three minutes on this and the
result is a labelled corpus that tells us which layer to spend the next build
on: capture, recognition, candidates, resolver, typing, memory, or the reply.

Labels are appended to tests/fixtures/labelled.jsonl. Nothing is overwritten.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent / "fixtures" / "labelled.jsonl"

HEARD = [("y", "heard it right", "heard"),
         ("c", "wrong, but a chip would have saved it", "chip_rescue"),
         ("t", "wrong, I had to type it", "typed_rescue"),
         ("w", "wrong, and it was accepted anyway", "wrong_accepted"),
         ("s", "skip", "skip")]
REPLY = [("y", "followed on naturally, and I knew what to say", "good"),
         ("r", "related, but gave me nothing to answer", "dead_end"),
         ("u", "unrelated to what I said", "unrelated"),
         ("s", "skip", "skip")]


def ask(prompt, opts):
    print(f"\n  {prompt}")
    for key, text, _ in opts:
        print(f"    {key}  {text}")
    while True:
        got = input("  > ").strip().lower()
        for key, _, tag in opts:
            if got == key:
                return tag
        print("  one of: " + ", ".join(k for k, _, _ in opts))


def main():
    import server
    try:
        turns = [json.loads(x) for x in
                 server.SESSION.read_text(encoding="utf-8").strip().split("\n") if x]
    except Exception:
        raise SystemExit(f"\n  No session recorded yet. Looked in {server.SESSION}\n")

    speech = [t for t in turns if t.get("kind") in ("heard", "failed", "typed")]
    if not speech:
        raise SystemExit("\n  Nothing to label.\n")

    print(f"\n  {len(speech)} turns. Two questions each. Ctrl-C to stop, "
          f"what you have done is kept.\n")
    rows, i = [], 0
    replies = [t for t in turns if t.get("kind") == "reply"]
    try:
        for t in speech:
            i += 1
            print(f"\n{'-' * 58}\n  turn {i} of {len(speech)}   [{t['kind']}]")
            if t.get("raw_pinyin"):
                print(f"    it heard:  {t['raw_pinyin']}")
            if t.get("accepted_pinyin"):
                print(f"    it used:   {t['accepted_pinyin']}")
            if t.get("heard_pinyin"):
                print(f"    it heard:  {t['heard_pinyin']}  (not used)")
            if t.get("typed"):
                print(f"    you typed: {t['typed']}  ->  {t.get('pinyin', '')}")
            row = {"turn": i, "kind": t.get("kind"),
                   "raw": t.get("raw_pinyin") or t.get("heard_pinyin", ""),
                   "accepted": t.get("accepted_pinyin") or t.get("pinyin", ""),
                   "conf": t.get("conf"), "state": t.get("state")}
            row["understanding"] = ask("what happened to what you said?", HEARD)
            rep = replies[i - 1] if i - 1 < len(replies) else None
            if rep:
                print(f"\n    they replied: {rep.get('pinyin', '')}")
                print(f"                  {rep.get('english', '')}")
                row["reply"] = ask("and the reply?", REPLY)
            rows.append(row)
    except KeyboardInterrupt:
        print("\n  stopped.")

    if not rows:
        return
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    n = len(rows)
    clean = sum(1 for r in rows if r.get("understanding") == "heard"
                and r.get("reply", "good") == "good")
    print(f"\n{'=' * 58}")
    print(f"  {clean} of {n} turns moved on without you fighting it\n")
    for label, key, tags in [("understanding", "understanding", HEARD),
                             ("replies", "reply", REPLY)]:
        print(f"  {label}")
        for _, text, tag in tags:
            c = sum(1 for r in rows if r.get(key) == tag)
            if c:
                print(f"    {c:3d}  {text}")
    print(f"\n  written to {OUT}\n")


if __name__ == "__main__":
    main()
