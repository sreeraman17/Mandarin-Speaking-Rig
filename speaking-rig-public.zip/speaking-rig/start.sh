#!/bin/bash
cd "$(dirname "$0")" || exit 1

PORT=8765
PIDFILE=".rig.pid"

if [ ! -d .venv ]; then
  echo
  echo "  Setup has not been run yet."
  echo "  In this folder, run:  ./setup.sh"
  echo
  read -r -p "  Press return to close." _
  exit 1
fi

# Stop only our own previous server, by recorded process id. Killing whatever
# happens to hold a port is somebody else's bad day.
if [ -f "$PIDFILE" ]; then
  OLD=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$OLD" ] && ps -p "$OLD" -o command= 2>/dev/null | grep -q "server:app"; then
    echo "  Stopping the previous Speaking Rig (pid $OLD)..."
    kill "$OLD" 2>/dev/null
    sleep 1
  fi
  rm -f "$PIDFILE"
fi

if ! curl -s --max-time 4 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  echo "  Starting Ollama..."
  open -a Ollama 2>/dev/null || ollama serve >/dev/null 2>&1 &
  for _ in 1 2 3 4 5 6 7 8; do
    sleep 1
    curl -s --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break
  done
fi

# shellcheck disable=SC1091
source .venv/bin/activate
find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null

echo
echo "  Speaking Rig is starting at http://127.0.0.1:$PORT"
echo "  Leave this window open while you use it."
echo "  Press Control-C here when you're finished."
echo

( sleep 2 && open "http://127.0.0.1:$PORT" ) &
uvicorn server:app --host 127.0.0.1 --port "$PORT" --log-level warning &
SERVER_PID=$!
echo "$SERVER_PID" > "$PIDFILE"
trap 'kill $SERVER_PID 2>/dev/null; rm -f "$PIDFILE"' EXIT INT TERM
wait $SERVER_PID
